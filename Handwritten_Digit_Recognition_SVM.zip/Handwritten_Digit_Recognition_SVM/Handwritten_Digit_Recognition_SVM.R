############################ Email Classification Problem ############################
# 1. Business Understanding
# 2. Data Understanding
# 3. Data Preparation
# 4. Model Building 
#  4.1 Linear SVM Model at C=1
#  4.2 Linear SVM Model at C=10
# 5  Using Kernel 
#  5.1. SVM with vanilladot kernel
#  5.2. SVM with rbfdot kernel
# 6. Model Parameter Tuning
#  6.1 Hyperparameter tuning and Cross Validation  - Linear - SVM 
#  6.2 Hyperparameter tuning and Cross Validation  - Radial - SVM 
#####################################################################################

# 1. Business Understanding: 
# A classic problem in the field of pattern recognition is that of handwritten digit recognition.
# The goal is to develop a model that can correctly identify the digit - in this case label
#(between 0-9) written in an image based on the given training data

# 2. Data Understanding 
# We'll use the MNIST data which is a large database of handwritten digits 
# where we have pixel values of each digit along with its label. The first field is named as label
# which is given in tis assignment
# We have 2 files training file and test file
# Training data set has 60000 obeservations with 785 variables (including label - first field)
# Test data set has 10000 obeservations with 785 variables (including label - first field)

#3. Data Preparation: 

# Loading libraries
library("caret")
library("dplyr")
library("ggplot2")
library("gridExtra")
library("readr")
library("kernlab")
library("e1071")
library("Rtsne")

# Setting worrking directory
setwd("D:/Personal/Abhishek/IIIT B Upgrad/Main-Course/Module4/Assignment")

# Loading data
train <- read.delim("data/mnist_train.csv",sep = ",", stringsAsFactors = F,header = F)
test <- read.delim("data/mnist_test.csv",sep = ",", stringsAsFactors = F,header = F)

#Renaming appropriate column to "label"
colnames(train)[1] <- "label"
colnames(test)[1] <- "label"


#Understanding Dimensions
dim(train)
dim(test)

#Structure of the dataset
str(train)
str(test)

#printing first few rows
head(train)
head(test)

# Summary
summary(train)
summary(test)

# Checking duplicate values
anyDuplicated(train)
anyDuplicated(test)

# Checking NAs
anyNA(train)
anyNA(test)

# check if there is uniform distribution on label to check if resample is needed
# plot shows no imbalance sample is needed
label.freq <- table(train$label)
barplot(label.freq)

#convert label variable to factor
train$label<-as.factor(train$label)
test$label<-as.factor(test$label)

#temporary dataframe for the label results
keeptrain<-as.data.frame(train$label)
keeptest<-as.data.frame(test$label)
#null label variable in both datasets
train$label<-NA
test$label<-NA

# Scaling the variables except label in training and test data set
train<-as.data.frame(scale(train))
train[is.na(train)]<- 0 #replace NA with 0
test<-as.data.frame(scale(test))
test[is.na(test)]<- 0
#add back label
train$label<-keeptrain$`train$label`
test$label<-keeptest$`test$label`

# using tsne
set.seed(1) # for reproducibility
tsne <- Rtsne(train[,-1], dims = 2, perplexity=30, verbose=TRUE, max_iter = 500)

# visualizing training data
colors = rainbow(length(unique(train$label)))
names(colors) = unique(train$label)
plot(tsne$Y, t='n', main="tsne")
text(tsne$Y, labels=train$label, col=colors[train$label])

# Sample of data from training and test to test model quickly
# Assumption is that 10000 observations from the training data is 
# taken hence accuracy might be low than actual
# We'll build model on training data set and test the model from 
# test data set created from test file and not from the training dataset data (as suggested by SME)
train_sample <- train[1:10000,]
test_sample <- test[1:3000,] # This is not used, just build this dataset if prediction takes long we can use this

#--------------------------------------------------------------------
# 4.1 Linear model - SVM  at Cost(C) = 1
#####################################################################

set.seed(100)

# Model with C = 1
model_1<- ksvm(label ~ ., data = train_sample,scale = FALSE,C=1)

# Predicting the model results
predict_1 <-predict(model_1, test)

# Confusion Matrix - Finding accuracy, Sensitivity and specificity
confusionMatrix(predict_1, test$label)

# Accuracy : 0.938
# Sensitivity : 0.9894 (Class: 1)
# Specificity : 0.9968 (Class: 1)

#--------------------------------------------------------------------
# 4.2 Linear model - SVM  at Cost(C) = 10
#####################################################################

# Model with C =10
model_2<- ksvm(label ~ ., data = train_sample,scale = FALSE,C=10)

# Predicting the model results
predict_2 <-predict(model_2, test)

# Confusion Matrix - Finding accuracy, Sensitivity and specificity
confusionMatrix(predict_2, test$label)

# Accuracy : 0.9474
# Sensitivity : 0.9912 (Class: 1)
# Specificity : 0.9970 (Class: 1)

#--------------------------------------------------------------------
# 5.1 SVM with vannilladot kernel
#####################################################################

model_linear_vanilla <- ksvm(label~ ., data = train_sample, scale = FALSE, kernel = "vanilladot")

# Predicting the model results
predict_3 <-predict(model_linear_vanilla, test)

# Confusion Matrix - Finding accuracy, Sensitivity and specificity
confusionMatrix(predict_3, test$label)

# Accuraccy : 0.9129
# Sensitivity : 0.9885 (Class: 1)
# Specificity : 0.9937 (Class: 1)

#--------------------------------------------------------------------
# 5.2 SVM with rbfdot kernel
#####################################################################

model_rbf <- ksvm(label~ ., data = train_sample, scale = FALSE, kernel = "rbfdot")

# Predicting the model results
predict_4 <-predict(model_rbf, test)

# Confusion Matrix - Finding accuracy, Sensitivity and specificity
confusionMatrix(predict_4, test$label)

# Accuracy : 0.938
# Sensitivity : 0.9877 (Class: 1)
# Specificity : 0.9968 (Class: 1)

#--------------------------------------------------------------------
# 6.1 Hyperparameter tuning and Cross Validation  - Linear - SVM 
#####################################################################

# We will use the train function from caret package to perform crossvalidation

trainControl <- trainControl(method="cv", number=5)
# Number - Number of folds 
# Method - cross validation

metric <- "Accuracy"

# making a grid of C values. 
grid <- expand.grid(C=seq(1, 5, by=1))

# Performing 5-fold cross validation
fit.svm <- train(label~., data=train_sample, method="svmLinear", metric=metric, 
                 tuneGrid=grid, trControl=trainControl)

# Printing cross validation result
print(fit.svm)

# Accuraccy : 0.9168

# Plotting "fit.svm" results
plot(fit.svm)

# Valdiating the model after cross validation on test data

evaluate_linear_test<- predict(fit.svm, test)
confusionMatrix(evaluate_linear_test, test$label)

# Accuracy    - 0.9129
# Sensitivity - 0.9885
# Specificity - 0.9937

#--------------------------------------------------------------------
# 6.2 Hyperparameter tuning and Cross Validation  - Radial - SVM 
#####################################################################

grid <- expand.grid(.sigma=c(0.025, 0.05), .C=c(0.1,0.5,1,2) )

set.seed(825)

fit.svm.radial <- train(label ~ ., data = train_sample, method = "svmRadial", trControl = trainControl, 
             preProc = c("center", "scale"),tuneLength = 8,metric = metric)

print(fit.svm.radial)
# The final values used for the model were
# sigma = 0.001222795 and C = 16.

plot(fit.svm.radial)


# Valdiating the model after cross validation on test data
evaluate_radial_test<- predict(fit.svm.radial, test)
confusionMatrix(evaluate_radial_test, test$label)

# Accuracy    - 0.9467
# Sensitivity - 0.9912
# Specificity - 0.9968

# Conclusion :: SVM model with Radial tuning and Linear model - SVM  at Cost(C) = 10 is giving best result (>94% accuracy)
# compare to other models. 