import org.apache.spark.SparkContext
import math._
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import java.io._

def calculateDistance(test: Array[String], train: Array[String], arrayLength: Int): Double = {
    var sum = 0.0
    var i = 2
    while (i < arrayLength) {
      sum = sum + Math.pow(train(i).toDouble - test(i).toDouble, 2.0)
      i = i + 1
    }
    return Math.sqrt(sum);
  }

  def KNearestNeighbors(trd: Array[Array[String]], tsd: Array[String], k: Int): Array[(String, String, Double)] = {
    val traindata = trd
    val testObj = tsd
    var totalColomns = traindata(0).length
    var finalresult = new Array[(String, String, Double)](trd.length)
    var resultCntr = 0

    var nVarDistance = 0.0;
    for (trainObj <- traindata) {
      nVarDistance = calculateDistance(testObj, trainObj, totalColomns)
      var trainingId = trainObj(0);
      finalresult(resultCntr) = (testObj(0), trainObj(0), nVarDistance)
      resultCntr = resultCntr + 1
    }
    val sortedByDistance = finalresult.sortBy(X => X._3).take(k)
    return sortedByDistance
  }
  
  val testdata = sc.textFile("/axp/open/cr2020uc/dev/knntest/test_1000.csv").map(d => d.split(",")) // .collect()
  val trainingdata = sc.textFile("/axp/open/cr2020uc/dev/knntest/f_training.csv").map(d => d.split(",")).collect()
  val k: Int = 5

  testdata.map { x => KNearestNeighbors(trainingdata, x, k) }.saveAsTextFile("/axp/open/cr2020uc/dev/knntest/output1/");
