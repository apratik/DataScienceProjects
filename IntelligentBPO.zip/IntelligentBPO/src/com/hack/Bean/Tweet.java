package com.hack.Bean;

public class Tweet {

}
