package com.hack.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;

public interface Constants {
	
	
	
	
	static Map<String, String> stationMaps = new HashMap<String, String>();
	static Set<String> drmList = new HashSet<String>();
	

}
