package com.hack.util;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class HandlerFileReader {
	
	public void readFileAndLoadMap(String fileName) throws IOException{
		
		List<String> lines = FileUtils.readLines(new File(fileName));
		
		for (String string : lines) {
			
			String[] stringArr = string.split(",");
			Constants.stationMaps.put(stringArr[0], stringArr[1]);
		}
		
		
		
	}
	
	public void loadDRMList(String filename) throws IOException{
		
		List<String> lines = FileUtils.readLines(new File(filename));
		
		for (String string : lines) {
			
			
			Constants.drmList.add(string.trim());
		}
		
		
		
	}

}
