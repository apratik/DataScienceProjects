package com.hack.util;

import twitter4j.AsyncTwitter;
import twitter4j.AsyncTwitterFactory;
import twitter4j.Status;
import twitter4j.TwitterAdapter;
import twitter4j.TwitterException;
import twitter4j.TwitterListener;
import twitter4j.TwitterMethod;

public class TwitterHomeStatusUpdate {

	public static void main(String[] args) {

		TwitterListener listener = new TwitterAdapter() {
			@Override
			public void updatedStatus(Status status) {
				System.out.println("Successfully updated the status to ["
						+ status.getText() + "].");
			}

			@Override
			public void onException(TwitterException te, TwitterMethod method) {
				if (method.equals(TwitterMethod.UPDATE_STATUS)) {
					te.printStackTrace();
				} else {
					throw new AssertionError("Should not happen");
				}
			}

		};

		// The factory instance is re-useable and thread safe.
		AsyncTwitterFactory factory = new AsyncTwitterFactory();
		AsyncTwitter asyncTwitter = factory.getInstance();
		asyncTwitter.addListener(listener);
		asyncTwitter.updateStatus(args[0]);

	}
}
