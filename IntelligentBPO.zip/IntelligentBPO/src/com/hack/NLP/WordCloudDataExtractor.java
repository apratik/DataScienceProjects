package com.hack.NLP;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import opennlp.tools.cmdline.postag.POSModelLoader;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.WhitespaceTokenizer;

public class WordCloudDataExtractor {

	POSModel model;
	POSTaggerME tagger;

	public WordCloudDataExtractor() {

		model = new POSModelLoader().load(new File("en-pos-maxent.bin"));
		tagger = new POSTaggerME(model);

	}

	public List<String> tagAndExtractData(String line) throws IOException {

		List<String> nounList = new ArrayList<String>();
		
		String whitespaceTokenizerLine[] = WhitespaceTokenizer.INSTANCE
					.tokenize(line.toLowerCase());

		String[] tags = tagger.tag(whitespaceTokenizerLine);

			for (int i = 0; i < tags.length; i++) {

				if (tags[i].equals("NN"))

					nounList.add(whitespaceTokenizerLine[i]);

			}

			
		return nounList;
	}

}
