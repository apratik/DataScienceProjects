package com.hack.UI;

import java.io.FileNotFoundException;
import java.io.IOException;

import twitter4j.conf.Configuration;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import com.hack.NLP.Classify;
import com.hack.NLP.WordCloudDataExtractor;
import com.hack.twitter.FinalReplySender;
import com.hack.twitter.ReplyMessage;
import com.hack.twitter.TwitterConfiguration;
import com.hack.twitter.TwitterStreamer;
import com.hack.util.DBUtil;
import com.hack.util.HandlerFileReader;
import com.hack.util.PropertiesReader;

public class MainRunner extends Application {

	private DBUtil dbUtil;
	private TwitterStreamer streamer;
	private Classify classify;
	private String status;
	private HandlerFileReader fileReader;
	private TwitterConfiguration configuration;
	private ReplyMessage message;
	private FinalReplySender finalReplySender;
	private Text statusText;
	private WordCloudDataExtractor cloudDataExtractor;

	public boolean Initialise() {

		try {

			PropertiesReader.readPropertiesReader();
			dbUtil = new DBUtil();
			classify = new Classify();
		    cloudDataExtractor = new WordCloudDataExtractor();
			configuration = new TwitterConfiguration();
			fileReader = new HandlerFileReader();
			fileReader.readFileAndLoadMap(PropertiesReader.handlerFilePath);
			finalReplySender = new FinalReplySender(configuration.getTwitterFinalReplyConf(), dbUtil);

			message = new ReplyMessage(configuration.getTwitterReplyConf(),dbUtil,finalReplySender);
			streamer = new TwitterStreamer(dbUtil, classify, this,
					configuration.getTwitterStreamConf(), message,finalReplySender,cloudDataExtractor);

			return true;
		} catch (Exception e) {

			e.printStackTrace();

			return false;
		}

	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException {

		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		final Button btn = new Button();
		btn.setText("Start");
		
		btn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				statusText.setText("Starting Application..");

				btn.setDisable(true);
				if (Initialise()) {

					statusText.setText("Application Started...");

				} else {

					statusText
							.setText("Not Able to start application,Please Check logs....");

				}

			}
		});

		VBox root = new VBox();

		statusText = new Text("Please Click on Start...");

		root.setSpacing(10);
		root.setPadding(new Insets(0, 20, 10, 20)); 
		
		
		
		root.getChildren().add(btn);
		root.getChildren().add(statusText);

		Scene scene = new Scene(root, 300, 250);

		primaryStage.setTitle("IntelligentBPO");
		primaryStage.setScene(scene);
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {

			@Override
			public void handle(WindowEvent arg0) {
				

				System.exit(0);

			}
		});

		primaryStage.show();

	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
