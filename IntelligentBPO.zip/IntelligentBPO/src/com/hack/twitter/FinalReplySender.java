package com.hack.twitter;

import twitter4j.Status;
import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.Configuration;
import twitter4j.json.DataObjectFactory;

import com.hack.util.DBUtil;

public class FinalReplySender {

	
	Twitter twitter;
	DBUtil dbUtil;
	
	public FinalReplySender(Configuration conf,DBUtil dbUtil) {
		
		 twitter = new TwitterFactory(conf).getInstance();
		 this.dbUtil=dbUtil;
	}
	
	public void sendFinalReplyToTweet(String tweetId,String msg) throws TwitterException{
		
		msg = msg.replaceAll("@IR_HelpDesk", "");
		
		System.out.println("Final Reply is  "+msg);
		StatusUpdate statusUpdate = new StatusUpdate(msg);
		
	    statusUpdate.setInReplyToStatusId(Long.parseLong(tweetId));
	    
	    
	    
	    Status status = twitter.updateStatus(statusUpdate);
	    
	   
	    
	    
	    dbUtil.confirmSupport(tweetId);
	    
	    
	      
	    
	    
	}
}
