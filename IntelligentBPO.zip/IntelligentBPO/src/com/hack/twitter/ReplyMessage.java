package com.hack.twitter;

import com.hack.util.DBUtil;

import twitter4j.Status;
import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.Configuration;
import twitter4j.json.DataObjectFactory;

public class ReplyMessage {
	
	Twitter twitter;
	DBUtil dbUtil;
	FinalReplySender finalReplySender;
	
	public ReplyMessage(Configuration conf,DBUtil dbUtil,FinalReplySender finalReplySender) {
		
		 twitter = new TwitterFactory(conf).getInstance();
		 this.dbUtil=dbUtil;
		 this.finalReplySender = finalReplySender;
	}
	
	public Status sendReplyToTweet(String tweetId,String username,String msg) throws TwitterException{
		
		msg = msg.replaceAll("@IR_HelpDesk", "@ir_support");
		
		System.out.println("Reply Message is"+msg);
		
		StatusUpdate statusUpdate = new StatusUpdate(username+" "+msg);
		
	    statusUpdate.setInReplyToStatusId(Long.parseLong(tweetId));
	    Status status = twitter.updateStatus(statusUpdate);
	    dbUtil.insertData(DataObjectFactory.getRawJSON(status));
	    
	    finalReplySender.sendFinalReplyToTweet(tweetId+"",  username+" Please reply with PNR and Geo Location on");
	    
	    
	    return status;
	    
	}
	

}
