package com.hack.twitter;

import twitter4j.FilterQuery;
import twitter4j.TwitterException;
import twitter4j.TwitterStreamFactory;
import twitter4j.conf.Configuration;

import com.hack.NLP.Classify;
import com.hack.NLP.WordCloudDataExtractor;
import com.hack.UI.MainRunner;
import com.hack.util.DBUtil;

public class TwitterStreamer {

	DBUtil dbUtil;
	Classify classify;
	MainRunner mainRunner;
	Configuration conf;
	ReplyMessage message;
	WordCloudDataExtractor cloudDataExtractor;
	FinalReplySender finalReplySender;
	
	public TwitterStreamer(DBUtil dbUtil,Classify classify,MainRunner mainRunner,Configuration conf,ReplyMessage message,FinalReplySender finalReplySender, WordCloudDataExtractor cloudDataExtractor) {
		
		this.dbUtil = dbUtil;
		this.classify =  classify;
		this.mainRunner = mainRunner;
		this.conf = conf;
		this.message = message;
		this.finalReplySender = finalReplySender;
		this.cloudDataExtractor = cloudDataExtractor;
		  
		CustomStatusListener listener = new CustomStatusListener(this.dbUtil,this.classify,this.mainRunner,this.message,this.finalReplySender,cloudDataExtractor);
		
		twitter4j.TwitterStream twitterStream = new TwitterStreamFactory(this.conf).getInstance();
		twitterStream.addListener(listener);
		
		FilterQuery filtre = new FilterQuery();
	    String[] keywordsArray = { "@IR_HelpDesk"};
	    filtre.track(keywordsArray);
	    twitterStream.filter(filtre);
		
	}
	
	
	
	
}
