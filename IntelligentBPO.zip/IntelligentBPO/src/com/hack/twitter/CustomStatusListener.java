package com.hack.twitter;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import opennlp.tools.util.InvalidFormatException;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.TwitterException;
import twitter4j.json.DataObjectFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hack.NLP.Classify;
import com.hack.NLP.WordCloudDataExtractor;
import com.hack.UI.MainRunner;
import com.hack.util.Constants;
import com.hack.util.DBUtil;

@SuppressWarnings("deprecation")
public class CustomStatusListener implements StatusListener {

	DBUtil dbUtil;
	Classify classify;
	MainRunner mainRunner;
	ReplyMessage message;
	WordCloudDataExtractor cloudDataExtractor;
	FinalReplySender finalReplySender;

	public CustomStatusListener(DBUtil dbUtil, Classify classify,
			MainRunner mainRunner, ReplyMessage message,
			FinalReplySender finalReplySender, WordCloudDataExtractor cloudDataExtractor) {

		this.dbUtil = dbUtil;
		this.classify = classify;
		this.mainRunner = mainRunner;
		this.message = message;
		this.finalReplySender = finalReplySender;
		this.cloudDataExtractor = cloudDataExtractor;

	}

	@Override
	public void onException(Exception arg0) {
		// TODO Auto-generated method stub

		mainRunner.setStatus("EXCEPTION");

		System.out.println("EXCEPTION"+arg0.getMessage());
		arg0.printStackTrace();
	}

	@Override
	public void onDeletionNotice(StatusDeletionNotice arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onScrubGeo(long arg0, long arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStallWarning(StallWarning arg0) {
		// TODO Auto-generated method stub

		System.out.println("STALL_WARNING");

	}

	@Override
	public void onStatus(Status status) {

		try {
			String jsonString = DataObjectFactory.getRawJSON(status);

			dbUtil.insertData(jsonString);

			// System.out.println(status.getUser().getScreenName()+"::"+status.getText());
			// System.out.println(DataObjectFactory.getRawJSON(status));

			// System.out.println("\n -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			

			System.out.println(status.getInReplyToStatusId());

			if (status.getInReplyToStatusId() == -1) {

				System.out.println("Reply Status id is -1");
				
				// System.out.println("classifying tweet");
				String sentiment = classify.test(status.getText());
				 System.out.println("Tweet Classified"+sentiment);

				if (sentiment.equals("A")) {
					
					ObjectMapper mapper = new ObjectMapper();
					
					JsonNode jsonNode = mapper.readValue(jsonString, JsonNode.class); 
					
					System.out.println("Inserting into db");

					StringBuffer buffer = new StringBuffer();

					buffer.append("{\"id\" : \"" + status.getId()+"\"");

					if(status.getPlace()!=null){
					buffer.append(",\"place\" : \""
							+ status.getPlace().getName() + "\"");

					}
					
					String text = status.getText().replaceAll("\n", " ");
					buffer.append(",\"text\" : \"" + text + "\"");

					buffer.append(",\"sentiment\" : \"" + sentiment + "\"");

					buffer.append(",\"user\" : \""
							+ status.getUser().getScreenName() + "\"");

					buffer.append(",\"retweetcount\" : \""
							+ status.getRetweetCount() + "\"");

					 if (jsonNode.has("created_at")) {
						 
						  buffer.append(",\"date\" : \"" +
						  getTwitterDate(jsonNode.get("created_at") .asText()) +
						  "\"}"); }

					/*
					 * if (jsonNode.has("id_str")) {
					 * 
					 * buffer.append("{\"id\" : \"" +
					 * jsonNode.get("id_str").asText());
					 * 
					 * 
					 * 
					 * 
					 * 
					 * }
					 * 
					 * if (jsonNode.has("created_at")) {
					 * 
					 * buffer.append("\",\"date\" : \"" +
					 * getTwitterDate(jsonNode.get("created_at") .asText()) +
					 * "\"}"); }
					 */

					List<String> tags = cloudDataExtractor
							.tagAndExtractData(status.getText());

					int i = 0;
					for (String tag : tags) {

						StringBuffer tagBuffer = new StringBuffer();

						tagBuffer.append("{\"id\" : \""
								+ status.getId() + "\"");

						tagBuffer.append(",\"tag\" : \"" + tag + "\"}");

						dbUtil.insertTagData(tagBuffer.toString());

						i++;

					}

					for (int j = 0; j < status.getUserMentionEntities().length; j++) {

						//if(Constants.drmList.contains(status.getUserMentionEntities()[j])){
							
						
						StringBuffer userMentionBuffer = new StringBuffer();

						userMentionBuffer.append("{\"id\" : \""
								+ status.getId() + "\"");

						userMentionBuffer.append(",\"user\" : \""
								+ status.getUserMentionEntities()[j].getScreenName() + "\"}");

						dbUtil.insertUserMentionEntities(userMentionBuffer
								.toString());
						
						//}

					}

					dbUtil.insertIntoTimeSeriesReport(buffer.toString());

					System.out.println(sentiment + "\t"
							+ status.getUser().getScreenName() + ""
							+ status.getText());

					 message.sendReplyToTweet(status.getId() + "",
							" @" + status.getUser().getScreenName(),
								status.getText());
					
					 
					
					

				}else if(sentiment.equals("I")){
					
					System.out.println("I\t"+status.getText());
				}
				
				
				
			}
			/*
			 * try { message.sendReplyToTweet(status.getId() + "", ""); } catch
			 * (TwitterException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); }
			 */

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (TwitterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void onTrackLimitationNotice(int arg0) {
		// TODO Auto-generated method stub

		mainRunner.setStatus("LIMIT");
		System.out.println("LIMIT");

	}

	public static String getTwitterDate(String date) throws ParseException {

		final String TWITTER = "EEE MMM dd HH:mm:ss ZZZZZ yyyy";
		SimpleDateFormat sf = new SimpleDateFormat(TWITTER);

		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

		// sf.setTimeZone(TimeZone.getTimeZone("UTC"));

		sf.setLenient(true);
		Date date2 = sf.parse(date);

		// System.out.println(date2);

		DateFormat targetFormat = new SimpleDateFormat("MM/dd/yy HH:mm:ss");

		return targetFormat.format(date2);
	}

}
