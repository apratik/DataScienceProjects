library(lubridate) 

library(dplyr)

setwd("D:/Personal/Abhishek/IIIT B Upgrad/Main-Course/Module2/EDA/UberCaseStudy")

# Loading csv for analysis

uber_request_data <- read.csv("Uber Request Data.csv",header = T, stringsAsFactors = FALSE)

str(uber_request_data)

View(uber_request_data)

summary(uber_request_data)

# Renaming columns to appropriate name

names(uber_request_data)[1] <- "Request_Id"

names(uber_request_data)[2] <- "Pickup_Point"

names(uber_request_data)[3] <- "Driver_Id"

names(uber_request_data)[5] <- "Request_Timestamp"

names(uber_request_data)[6] <- "Drop_Timestamp"


# Trim spaces from columns of dataframe

uber_request_data$Request_Id <- trimws(uber_request_data$Request_Id)

uber_request_data$Pickup_Point <- trimws(uber_request_data$Pickup_Point)

uber_request_data$Driver_Id <- trimws(uber_request_data$Driver_Id)

uber_request_data$Status <- trimws(uber_request_data$Status)

uber_request_data$Request_Timestamp <- trimws(uber_request_data$Request_Timestamp)

uber_request_data$Drop_Timestamp <- trimws(uber_request_data$Drop_Timestamp)


####### Start Processing Request Timestamp ##################

# Produces NA when format is not "%d-%m-%Y %H:%M"

Request_timestamp_format1 <- as.POSIXct(uber_request_data$Request_Timestamp, format = "%d-%m-%Y %H:%M", tz = "Asia/Calcutta")

# Produces NA when format is not "%d/%m/%Y %H:%M"

Request_timestamp_format2 <- as.POSIXct(uber_request_data$Request_Timestamp, format = "%d/%m/%Y %H:%M", tz = "Asia/Calcutta")


# Combine both while keeping their ranks as is

Request_timestamp_format1[is.na(Request_timestamp_format1)] <- Request_timestamp_format2[!is.na(Request_timestamp_format2)]

# Put common formatted data in dataframe for further use

uber_request_data$Request_Timestamp <- Request_timestamp_format1

# Extract Request Date

uber_request_data$Request_Date <- as.Date(uber_request_data$Request_Timestamp)

# Extract Request Time

uber_request_data$Request_Time <- format(uber_request_data$Request_Timestamp,"%H:%M:%S")

# Extract Hour of Day

uber_request_data$Request_Hour <- as.numeric(substr(uber_request_data$Request_Time,1,2))


####### Start Processing Drop Timestamp ###################

# Produces NA when format is not "%d-%m-%Y %H:%M"

Drop_timestamp_format1 <- as.POSIXct(uber_request_data$Drop_Timestamp, format = "%d-%m-%Y %H:%M", tz = "Asia/Calcutta")

# Produces NA when format is not "%d/%m/%Y %H:%M"

Drop_timestamp_format2 <- as.POSIXct(uber_request_data$Drop_Timestamp, format = "%d/%m/%Y %H:%M", tz = "Asia/Calcutta")

# Combine both while keeping their ranks as is

Drop_timestamp_format1[is.na(Drop_timestamp_format1) & !is.na(Drop_timestamp_format2)]<- Drop_timestamp_format2[!is.na(Drop_timestamp_format2) & is.na(Drop_timestamp_format1)]

# Put common formatted data in dataframe for further use

uber_request_data$Drop_Timestamp <- Drop_timestamp_format1

# Extract Drop Date

uber_request_data$Drop_Date <- as.Date(uber_request_data$Drop_Timestamp)

# Extract Drop Time

uber_request_data$Drop_Time <- format(uber_request_data$Drop_Timestamp,"%H:%M:%S")

# Extract Drop Hour

uber_request_data$Drop_Hour <- as.numeric(substr(uber_request_data$Drop_Time,1,2))


# Trip Duration in minutes

uber_request_data$Trip_Duration_Minutes <- round((uber_request_data$Drop_Timestamp - uber_request_data$Request_Timestamp),digits=2)


###### Create Timeslot Buckets ##########################

uber_request_data$Request_Time_Slot [uber_request_data$Request_Hour >= 4 & uber_request_data$Request_Hour < 8] = "Early Morning"
uber_request_data$Request_Time_Slot [uber_request_data$Request_Hour >= 8 & uber_request_data$Request_Hour < 12] = "Morning"
uber_request_data$Request_Time_Slot [uber_request_data$Request_Hour >= 12 & uber_request_data$Request_Hour < 15] = "Early Afternoon"
uber_request_data$Request_Time_Slot [uber_request_data$Request_Hour >= 15 & uber_request_data$Request_Hour < 17] = "Late Afternoon"
uber_request_data$Request_Time_Slot [uber_request_data$Request_Hour >= 17 & uber_request_data$Request_Hour < 19] = "Early Evening"
uber_request_data$Request_Time_Slot [uber_request_data$Request_Hour >= 19 & uber_request_data$Request_Hour < 21] = "Late Evening"
uber_request_data$Request_Time_Slot [uber_request_data$Request_Hour >= 21 | (uber_request_data$Request_Hour >= 0 & uber_request_data$Request_Hour < 4)] = "Night"

# Write CSV for Analysis (Trip Frequency, Pickup Point and Timeslot Analysis)

write.csv(uber_request_data,"uber_derived_data.csv", row.names = F)

# Start Data Aggregation for Timeslot wise Demand Supply Analysis

uber_demand_timeslot_summary <- uber_request_data %>% group_by(Request_Time_Slot) %>%  count(Request_Time_Slot)

uber_supply <- uber_request_data[-which(uber_request_data$Status %in% c("Cancelled","No Cars Available")),]

uber_supply_timeslot_summary <- uber_supply %>% group_by(Request_Time_Slot) %>%  count(Request_Time_Slot)

uber_demand_supply_timeslot_summary <- merge(uber_demand_timeslot_summary,uber_supply_timeslot_summary, by = "Request_Time_Slot")

names(uber_demand_supply_timeslot_summary)[2] <- "demand"

names(uber_demand_supply_timeslot_summary)[3] <- "supply"

View(uber_demand_supply_timeslot_summary)

write.csv(uber_demand_supply_timeslot_summary,"uber_demand_supply_timeslot_summary.csv", row.names = F)

# Start Data Aggregation for Pickup point wise Demand Supply Analysis

uber_demand_pickup_summary <- uber_request_data %>% group_by(Pickup_Point) %>%  count(Pickup_Point)

#uber_supply <- uber_request_data[-which(uber_request_data$Status %in% c("Cancelled","No Cars Available")),]

uber_supply_pickup_summary <- uber_supply %>% group_by(Pickup_Point) %>%  count(Pickup_Point)

uber_demand_supply_pickup_summary <- merge(uber_demand_pickup_summary,uber_supply_pickup_summary, by = "Pickup_Point")

names(uber_demand_supply_pickup_summary)[2] <- "demand"

names(uber_demand_supply_pickup_summary)[3] <- "supply"

View(uber_demand_supply_pickup_summary)

write.csv(uber_demand_supply_pickup_summary,"uber_demand_supply_pickup_summary.csv", row.names = F)  

View(uber_request_data)


