#setwd("D:\\Personal\\Abhishek\\IIIT B Upgrad\\Main-Course\\Capstone")
##------- Assignment - Acquisition Analytics-------------##
#----------------------------------------------------------
# The standard process followed in this projects is:
# 1. Business Understanding
# 2. Data Understanding and Exploratory Data Analysis 
# 3. Model Building - Logistics Regression With Demographic Dataset
# 4. Binning and Data Preparation with Information Value and WOE analysis
# 5. Model Building
#       1 - Logistics Regression With Balanced Credit Bureau and Demographic Dataset
#       2 - Random Forest With Balanced Credit Bureau and Demographic Dataset
#       3 - Decision Tree With Balanced Credit Bureau and Demographic Dataset
# 6. Model Evaluation
# 7. Scorecard Development
# 8. Analysis of Non Approved Applicants and benefits

## Clearing Objects
rm(list = ls())

# Load library
library(scales)
library(dummies)
library(MASS)
library(car)
library(caret)
library(e1071)
library(stringr)
library(ranger)
require(dplyr)
library(dplyr)
library(rpart)
library(rattle)
library(caTools)
library("rpart.plot")
library(data.table)
library(scorecard)
library(randomForest)
library(ROCR)
library(corrplot)
library(pROC)
library(mice)
library(smbinning)
library(plyr)
library(ggplot2)
library(Information)
library(ROSE)
library(mlr)
library("DMwR")
library("FSelector")
library("ggthemes")
library(stargazer)
library(InformationValue)
library(devtools)
library(woe)

#--------------------------------------------------------------------------------------------------------------------
# 1. Business Understanding
#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------
# CredX is a leading credit card provider that gets thousands of credit card applicants every year. But in the past 
# few years, it has experienced an increase in credit loss. The CEO believes that the best strategy to mitigate 
# credit risk is to 'acquire the right customers'.
# Along with this we need to analyze rejected application and create the scorecard for decision making
#--------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------
# 2. Data Understanding and Exploratory Data Analysis
#--------------------------------------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------------------------------------
# Demographic Data set
#--------------------------------------------------------------------------------------------------------------

# Loading the data files
# Demographic data set
# Rows     Columns
# 71295    12
demographic_data <- read.csv("Demographic data.csv", stringsAsFactors=FALSE, na.strings=c(""," ","NA"))

setnames(demographic_data, old=c("Application.ID","Age","Gender","Marital.Status..at.the.time.of.application.","No.of.dependents","Income","Education","Profession","Type.of.residence","No.of.months.in.current.residence","No.of.months.in.current.company","Performance.Tag"), 
         new=c("application_id","age","gender","marital_status","num_of_dependents","income","education","profession","type_of_residence","num_months_in_current_residence","num_months_in_current_company","performance_tag"))

str(demographic_data)
summary(demographic_data)
dim(demographic_data)

demographic_data <- demographic_data[!duplicated(demographic_data$application_id), ]
dim(demographic_data)


#---------------------------------------------------------------------------------------------------------------------
# Credit Bureau Data set
#--------------------------------------------------------------------------------------------------------------
# Rows     Columns
# 71295    19
credit_bureau_data <- read.csv("Credit Bureau data.csv", stringsAsFactors=FALSE, na.strings=c(""," ","NA"))
str(credit_bureau_data)
summary(credit_bureau_data)

setnames(credit_bureau_data, old=c("Application.ID","No.of.times.90.DPD.or.worse.in.last.6.months","No.of.times.60.DPD.or.worse.in.last.6.months","No.of.times.30.DPD.or.worse.in.last.6.months","No.of.times.90.DPD.or.worse.in.last.12.months","No.of.times.60.DPD.or.worse.in.last.12.months","No.of.times.30.DPD.or.worse.in.last.12.months","Avgas.CC.Utilization.in.last.12.months","No.of.trades.opened.in.last.6.months","No.of.trades.opened.in.last.12.months","No.of.PL.trades.opened.in.last.6.months","No.of.PL.trades.opened.in.last.12.months","No.of.Inquiries.in.last.6.months..excluding.home...auto.loans.","No.of.Inquiries.in.last.12.months..excluding.home...auto.loans.","Presence.of.open.home.loan","Outstanding.Balance","Total.No.of.Trades","Presence.of.open.auto.loan","Performance.Tag"),
         new=c("application_id","num_of_times_90_dpd_or_worse_in_last_6_months","num_of_times_60_dpd_or_worse_in_last_6_months","num_of_times_30_dpd_or_worse_in_last_6_months","num_of_times_90_dpd_or_worse_in_last_12_months","num_of_times_60_dpd_or_worse_in_last_12_months","num_of_times_30_dpd_or_worse_in_last_12_months","avgas_cc_utilization_in_last_12_months","num_of_trades_opened_in_last_6_months","num_of_trades_opened_in_last_12_months","num_of_pl_trades_opened_in_last_6_months","num_of_pl_trades_opened_in_last_12_months","num_of_inquiries_in_last_6_months_excluding_home_auto_loans","num_of_inquiries_in_last_12_months_excluding_home_auto_loans","presence_of_open_home_loan","outstanding_balance","total_num_of_trades","presence_of_open_auto_loan","performance_tag"))


str(credit_bureau_data)
summary(credit_bureau_data)
dim(credit_bureau_data)
credit_bureau_data <- credit_bureau_data[!duplicated(credit_bureau_data$application_id), ]
dim(credit_bureau_data)

# check for blanks - No blanks found in data set

sapply(demographic_data, function(x) length(which(trimws(x,which = "both") == ""))) # checking for blank "" values

sapply(credit_bureau_data, function(x) length(which(trimws(x,which = "both") == ""))) # checking for blank "" values

# Removing whitespaces in columns

demographic_data <-data.frame(lapply(demographic_data, function(x) if(class(x)=="character") trimws(x) else(x)), stringsAsFactors=F)

credit_bureau_data <-data.frame(lapply(credit_bureau_data, function(x) if(class(x)=="character") trimws(x) else(x)), stringsAsFactors=F)

# Merging Demographic and Credit Bureau Data on application_id
credx_master_data <- merge(x = demographic_data, y = credit_bureau_data, by = "application_id", all = T)
str(credx_master_data)
summary(credx_master_data)  

# Checking duplicate data
sum(duplicated(credx_master_data$application_id)) 

# Performance.Tag is same in both Demographic Data and Credit Bureau Data
credx_master_data$difference <- credx_master_data$performance_tag.x - credx_master_data$performance_tag.y

credx_master_data$difference <- factor(credx_master_data$difference)

## Remove one performance_tag
credx_master_data <- credx_master_data[, !(names(credx_master_data) %in% c("difference", "performance_tag.x"))]

# Renaming to performance_tag.x
colnames(credx_master_data)[29] <- "performance_tag"

## Check Master data set for NA's - It is observed that there are NA's in data set
sapply(credx_master_data, function(x) sum(is.na(x)))



#---------------------------------------------------------------------------------------------------------------------
# 3. Exploratory Data Analysis
#--------------------------------------------------------------------------------------------------------------

#stargazer(demographic_data, type = "text", title="Demographic Data Descriptive statistics", digits = 2, out="DemographicData_DescriptiveStat.txt")

#stargazer(credit_bureau_data, type = "text", title="Credit Bureau Data Descriptive statistics", digits = 2, out="CreditBureauData_DescriptiveStat.txt")

#stargazer(credx_master_data, type = "text", title="Master Data Descriptive statistics", digits = 2, out="MasterData_DescriptiveStat.txt")

DataExplorer::GenerateReport(credx_master_data)

# Function for distribution of categorical variables 
univariate_categorical <- function(dataset,var,var_name){
  dataset %>% ggplot(aes(x = as.factor(var))) +
    geom_bar(aes(y = (..count..)/sum(..count..))) +
    geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +
    scale_y_continuous(labels = percent) +
    labs(title = var_name, y = "Percent", x = var_name)+theme(
      axis.text.y=element_blank(), axis.ticks=element_blank(),
      axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
    ) 
}

str(credx_master_data)

# Attribute Distribution
univariate_categorical(credx_master_data,credx_master_data$age,'age')
univariate_categorical(credx_master_data,credx_master_data$gender,'gender')
univariate_categorical(credx_master_data,credx_master_data$marital_status,'marital_status')
univariate_categorical(credx_master_data,credx_master_data$num_of_dependents,'num_of_dependents')
univariate_categorical(credx_master_data,credx_master_data$income,'income')
univariate_categorical(credx_master_data,credx_master_data$education,'education')
univariate_categorical(credx_master_data,credx_master_data$profession,'profession')
univariate_categorical(credx_master_data,credx_master_data$type_of_residence,'type_of_residence')
univariate_categorical(credx_master_data,credx_master_data$num_months_in_current_residence,'num_months_in_current_residence')
univariate_categorical(credx_master_data,credx_master_data$num_months_in_current_company,'num_months_in_current_company')
univariate_categorical(credx_master_data,credx_master_data$num_of_times_90_dpd_or_worse_in_last_6_months,'num_of_times_90_dpd_or_worse_in_last_6_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_times_60_dpd_or_worse_in_last_6_months,'num_of_times_60_dpd_or_worse_in_last_6_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_times_30_dpd_or_worse_in_last_6_months,'num_of_times_30_dpd_or_worse_in_last_6_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_times_90_dpd_or_worse_in_last_12_months,'num_of_times_90_dpd_or_worse_in_last_12_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_times_60_dpd_or_worse_in_last_12_months,'num_of_times_60_dpd_or_worse_in_last_12_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_times_30_dpd_or_worse_in_last_12_months,'num_of_times_30_dpd_or_worse_in_last_12_months')
univariate_categorical(credx_master_data,credx_master_data$avgas_cc_utilization_in_last_12_months,'avgas_cc_utilization_in_last_12_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_trades_opened_in_last_6_months,'num_of_trades_opened_in_last_6_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_trades_opened_in_last_12_months,'num_of_trades_opened_in_last_12_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_pl_trades_opened_in_last_6_months,'num_of_pl_trades_opened_in_last_6_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_pl_trades_opened_in_last_12_months,'num_of_pl_trades_opened_in_last_12_months')
univariate_categorical(credx_master_data,credx_master_data$num_of_inquiries_in_last_6_months_excluding_home_auto_loans,'num_of_inquiries_in_last_6_months_excluding_home_auto_loans')
univariate_categorical(credx_master_data,credx_master_data$num_of_inquiries_in_last_12_months_excluding_home_auto_loans,'num_of_inquiries_in_last_12_months_excluding_home_auto_loans')
univariate_categorical(credx_master_data,credx_master_data$presence_of_open_home_loan,'presence_of_open_home_loan')
# Commenting this as it takes lot of time
# univariate_categorical(credx_master_data,credx_master_data$outstanding_balance,'outstanding_balance')
univariate_categorical(credx_master_data,credx_master_data$total_num_of_trades,'total_num_of_trades')
univariate_categorical(credx_master_data,credx_master_data$presence_of_open_auto_loan,'presence_of_open_auto_loan')
univariate_categorical(credx_master_data,credx_master_data$performance_tag,'performance_tag')


# See Ouliers in data - which will be taken care in WOE imputation

meltData <- melt(credx_master_data[,-c(1,29)])

p <- ggplot(meltData, aes(factor(variable), value)) 
p + geom_boxplot() + facet_wrap(~variable, scale="free")


# Identifying columns and missing data percentage for Credit Bureau Data - Instead of "missingCredit_values" below provides percentage in right format along with number, can try plotting on this

data=credx_master_data
ncol=rep(nrow(data) ,each=ncol(data))
missing_percentage=as.data.frame(cbind(colnames=names(data),ncol,nmsg=as.integer(as.character(as.vector(apply(data, 2, function(x) length(which(is.na(x)))))))))
missing_percentage$nmsg=as.integer(levels(missing_percentage$nmsg))[missing_percentage$nmsg]
missing_percentage=cbind(missing_percentage,percent_missing=round(as.double(missing_percentage$nmsg/ncol*100),2))
missing_percentage

md.pattern(credx_master_data)


# data frame with NA's performance tag
credx_master_data_with_na <- subset(credx_master_data, is.na(credx_master_data$performance_tag))

## Remove NA from master data set
credx_master_final_data <- credx_master_data[!is.na(credx_master_data$performance_tag),]

str(credx_master_final_data)

dim(credx_master_data)

#-------------------------------------------------------------------------------------------------------------------------------
# 3. Model Building - Logistics Regression With Demographic Dataset
#-------------------------------------------------------------------------------------------------------------------------------
demo_data <- credx_master_data[2:11]
demo_data$performance_tag <- credx_master_data$performance_tag 

table(demo_data$performance_tag)
#---------------------------------------------------------    

#creating dummy variables

demo_data$performance_tag <- as.integer(demo_data$performance_tag)

demo_data <- dummy.data.frame(demo_data)

demo_data$performance_tag <- as.factor(ifelse(demo_data$performance_tag == 1, "yes", "no"))

within(demo_data, rm("genderNA", "marital_statusNA", "educationNA", "professionNA", "type_of_residenceNA"))

df = subset(demo_data, select = -c(genderNA, marital_statusNA, educationNA, professionNA, type_of_residenceNA) )

# splitting into train and test data

set.seed(1)

split_indices <- caTools::sample.split(df$performance_tag, SplitRatio = 0.70)

train_demo <- df[split_indices, ]

test_demo <- df[!split_indices, ]

nrow(train_demo)/nrow(df)

nrow(test_demo)/nrow(df)

logistic_1 <- glm(performance_tag ~ ., family = "binomial", data = train_demo)
summary(logistic_1)
# Error in vif.default(logistic_1) : 
#there are aliased coefficients in the model
vif(logistic_1)

#--------------------------------------------------------------------------------------------------------------
# Using stepwise algorithm for removing insignificant variables 
logistic_2 <- glm(formula = performance_tag ~ age + genderF + genderM + marital_statusMarried + marital_statusSingle + num_of_dependents +
                    income + educationBachelor + educationMasters + educationOthers + educationPhd + educationProfessional +
                    professionSAL + professionSE + professionSE_PROF +   `type_of_residenceCompany provided` +  `type_of_residenceLiving with Parents` + type_of_residenceOthers +
                    type_of_residenceOwned + type_of_residenceRented + num_months_in_current_residence +  num_months_in_current_company,
                    family = "binomial", data = train_demo)

summary(logistic_2)
# stepAIC has removed some variables and only the following ones remain
#--------------------------------------------------------------------------------------------------------------

# Removing all except num of months in current company, income because of high P value
logistic_3 <- glm(formula = performance_tag ~ income +num_months_in_current_company,
                  family = "binomial", data = train_demo)

summary(logistic_3)

#--------------------------------------------------------------------------------------------------------------
logistic_final <- logistic_3
#---------------------------------------------------------    

# Predicting probabilities of responding for the test data

predictions_logit <- predict(logistic_final, newdata = test_demo[, ], type = "response")
summary(predictions_logit)

#--------------------------------------------------------- 


## Model Evaluation: Logistic Regression

# Let's use the probability cutoff of 50%.

predicted_response <- factor(ifelse(predictions_logit >= 0.50, "yes", "no"))

# Creating confusion matrix for identifying the model evaluation.
conf <- caret::confusionMatrix(predicted_response, test_demo$performance_tag, positive = "yes")

conf

#Confusion Matrix and Statistics

#Reference
#Prediction    no   yes
#no  20075   884
#yes     0     0

#---------------------------------------------------------    

# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_response <- factor(ifelse(predictions_logit >= cutoff, "yes", "no"))
  conf <- caret::confusionMatrix(predicted_response, test_demo$performance_tag, positive = "yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

#---------------------------------------------------------    

# Creating cutoff values from 0.01 to 0.99 for plotting and initiallizing a matrix of 1000 X 4.

s = seq(.01,.99,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

# plotting cutoffs 
plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.01)]


# Let's choose a cutoff value of 12% for final model

predicted_response <- factor(ifelse(predictions_logit >= 0.128, "yes", "no"))

conf_final <- caret::confusionMatrix(predicted_response, test_demo$performance_tag, positive = "yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

# Accuracy - 0.9578498   
acc
#0 
sens
# 1 
spec

# Interpretation :: The above parameter shows that the model is not a good model and further analysis
#------------------------------------------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------------------------------------------------
# 4. Binning and Data Preparation with Information Value and WOE analysis
#-------------------------------------------------------------------------------------------------------------------------------


# IV and WOE calculation
IV <- create_infotables(credx_master_final_data[,-1],y="performance_tag",ncore = 2)

# IV table for understanding
IV$Tables

# create DF with IV values
IvDF <- IV$Summary

for(i in 1:nrow(IvDF)){
  
  if (IvDF$IV[i]<0.02){
    IvDF$feedback[i] = "Useless"
    
  } else if(IvDF$IV[i]>=0.02& IvDF$IV[i]<0.1){
    IvDF$feedback[i] = "Weak"
    
  } else if(IvDF$IV[i]>=0.1 & IvDF$IV[i]<0.3){
    IvDF$feedback[i] = "Medium"
    
  }else if(IvDF$IV[i]>=0.3 & IvDF$IV[i]<0.5){
    IvDF$feedback[i] = "Strong"
    
  }else if(IvDF$IV[i]>0.1 & IvDF$IV[i]<0.3){
    IvDF$feedback[i] = "Suspicious"
  }
}

# Change to Factor 
IvDF$Variable <- as.factor(IvDF$Variable)


# Extracting "Strong" and "Medium" levels 
k1 <- IvDF[which(IvDF$feedback=="Strong"|IvDF$feedback=="Medium"),1]
final_data_set <- credx_master_final_data[,colnames(credx_master_final_data) %in% k1]


# WOE analysis
str(final_data_set)
final_data_set <- cbind(final_data_set,credx_master_final_data[,29])
colnames(final_data_set)[16] <- "performance_tag"
IV_1 <- create_infotables(final_data_set,y="performance_tag",ncore = 2)


# WOE IV understanding
IV_1$Tables

# DF contains all values
IV_1$Summary

#View(IV_1)

#View(IvDF)

# replace numeric variables to factors / change the level and convert in to numeric  

woe_table <- final_data_set

dim(woe_table)

IV_1 <- IV_1


# Now, let's replace the variables with woe value for model building 
matrix_1 <- list()

for(i in 1 :15) {
  
  matrix_1[[i]] = cbind(IV_1$Tables[[i]][1],IV_1$Tables[[i]][4])
  
}
matrix_1



woe_function <- function(matrix , variable) {
  
  for(i in 1 : nrow(matrix)){
    
    k <- matrix
    
    s <- k[i,1]
    
    if(s=="NA"){
      
      replace_by = k[i,2]
      
      variable[which(is.na(variable))] = replace_by
      
    } else {
      
      s <- str_replace_all(s, fixed(" "), "")
      
      s_list <- strsplit(gsub("\\[|\\]", "", s), split=",")
      
      n = as.integer(s_list[[1]][[1]])
      m = as.integer(s_list[[1]][[2]])
      
      range <- n:m
      
      replace_by = k[i,2]
      
      
      variable[which(variable %in% range)] = replace_by
      final_data_set[,14]
      
    }
    
  }
  
  return(variable)
}

empty_matrix <- matrix(0,nrow(final_data_set),ncol(final_data_set))

for(i in 1:ncol(final_data_set[,-16]))
{
  
  empty_matrix[,i] = woe_function(matrix_1[[i]],final_data_set[,i])  
  
}


woe_data <- data.frame(empty_matrix)



for(i in 1:ncol(woe_data)){
  
  colnames(woe_data)[i] <- colnames(final_data_set)[i]
  
}


woe_data$performance_tag <- final_data_set$performance_tag


# let's create a plot of woe for all the variables 

names <- names(IV_1$Tables)

plots <- list()

for (i in 1:length(names)){
  
  plots[[i]] <- plot_infotables(IV_1, names[i])
  
}

# Lets see the plots

plots[1:ncol(woe_data)]
plots[1]


##################################################################################

#View(woe_data)

# with below correlation it is observed that funded_amt, loan_amt are strong correlated
cor(woe_data)

cormat <- round(cor(woe_data),2)
head(cormat)
melted_cormat <- melt(cormat)
melted_cormat

ggplot(data = melted_cormat, aes(x=Var1, y=Var2, fill=value)) + geom_tile()

#-------------------------------------------------------------------------------------------------------------------------------
# 5.1 Model Building
#       - Logistics Regression With Balanced Credit Bureau and Demographic Dataset
#-------------------------------------------------------------------------------------------------------------------------------

# Convert performance_tag to factor
woe_data$performance_tag <- as.factor(woe_data$performance_tag)

#Check Class Bias
round(prop.table(table(woe_data$performance_tag))*100) 

# Percentage split
# 0   1 
# 96  4

set.seed(100)

split_indices_model <- sample.split(woe_data$performance_tag, SplitRatio = 0.70)

train_model_data <- woe_data[split_indices_model, ]

test_model_data <- woe_data[!split_indices_model, ]

nrow(train_model_data)/nrow(woe_data)

nrow(test_model_data)/nrow(woe_data)

# 96% value 0 and 4% 1. Showing Imbalanced classification of data.
round(prop.table(table(train_model_data$performance_tag))*100) 
#96% value 0 and 4%  1. Showing Imbalanced classification of data.
round(prop.table(table(test_model_data$performance_tag))*100)

# Using SMOTE for balancing data -----------------------------

train_smoted <- SMOTE(performance_tag ~ ., train_model_data, perc.over = 600,perc.under=100) 
test_smoted <- SMOTE(performance_tag ~ ., test_model_data, perc.over = 600,perc.under=100) 

# 96% value 0 and 4% 1. Showing Imbalanced classification of training data.
round(prop.table(table(train_smoted$performance_tag))*100) 

# Using logistic regression model
# 1 implies default, 0 implies good
initial_model = glm(performance_tag ~ ., data = train_smoted, family = "binomial")

summary(initial_model)

# Run Stepwise model to remove insignificant independent variables from model.
best_model_1 = stepAIC(initial_model, direction = "both")

# Checking summary of "best_model_1" 
summary(best_model_1)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_1))


# Using logistic regression model
# 1 implies default, 0 implies good
initial_model = glm(Performance.Tag ~ ., data = train, family = "binomial")

summary(initial_model)

# Run Stepwise model to remove insignificant indipendent variables from model.
best_model_1 = stepAIC(initial_model, direction = "both")

# Checking summary of "best_model_1" 
summary(best_model_1)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_1))

# Removing num_of_pl_trades_opened_in_last_12_months due to high vif

best_model_2 <- glm(formula = performance_tag ~ num_of_times_30_dpd_or_worse_in_last_6_months + 
                      num_of_times_90_dpd_or_worse_in_last_12_months + num_of_times_60_dpd_or_worse_in_last_12_months + 
                      avgas_cc_utilization_in_last_12_months + num_of_trades_opened_in_last_12_months + 
                      num_of_pl_trades_opened_in_last_6_months + num_of_inquiries_in_last_6_months_excluding_home_auto_loans + 
                      num_of_inquiries_in_last_12_months_excluding_home_auto_loans + 
                      outstanding_balance + total_num_of_trades, family = "binomial", 
                    data = train_smoted)

# Checking summary of "best_model_2"
summary(best_model_2)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_2))

# Removing num_of_trades_opened_in_last_12_months due to high vif

best_model_3 <- glm(formula = performance_tag ~ num_of_times_30_dpd_or_worse_in_last_6_months + 
                      num_of_times_90_dpd_or_worse_in_last_12_months + num_of_times_60_dpd_or_worse_in_last_12_months + 
                      avgas_cc_utilization_in_last_12_months + num_of_pl_trades_opened_in_last_6_months + num_of_inquiries_in_last_6_months_excluding_home_auto_loans + 
                      num_of_inquiries_in_last_12_months_excluding_home_auto_loans + 
                      outstanding_balance + total_num_of_trades, family = "binomial", 
                    data = train_smoted)

# Checking summary of "best_model_3"
summary(best_model_3)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_3))

#------------------------------------------------------------------------------------------

# Removing num_of_times_30_dpd_or_worse_in_last_6_months due to high vif

best_model_4 <- glm(formula = performance_tag ~ num_of_times_90_dpd_or_worse_in_last_12_months +
                      num_of_times_60_dpd_or_worse_in_last_12_months + avgas_cc_utilization_in_last_12_months +
                      num_of_pl_trades_opened_in_last_6_months + num_of_inquiries_in_last_6_months_excluding_home_auto_loans +
                      num_of_inquiries_in_last_12_months_excluding_home_auto_loans +
                      outstanding_balance + total_num_of_trades, family = "binomial", data = train_smoted)
# Checking summary of "best_model_4"
summary(best_model_4)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_4))


# Removing num_of_inquiries_in_last_12_months_excluding_home_auto_loans due to high vif

best_model_5 <- glm(formula = performance_tag ~ num_of_times_90_dpd_or_worse_in_last_12_months + 
                      num_of_times_60_dpd_or_worse_in_last_12_months + 
                      avgas_cc_utilization_in_last_12_months + 
                      num_of_pl_trades_opened_in_last_6_months + 
                      num_of_inquiries_in_last_6_months_excluding_home_auto_loans +
                      outstanding_balance + total_num_of_trades, family = "binomial", data = train_smoted)

# Checking summary of "best_model_5"
summary(best_model_5)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_5))


# Removing total_num_of_trades due to high vif

best_model_6 <- glm(formula = performance_tag ~ num_of_times_90_dpd_or_worse_in_last_12_months + 
                      num_of_times_60_dpd_or_worse_in_last_12_months + 
                      avgas_cc_utilization_in_last_12_months + 
                      num_of_pl_trades_opened_in_last_6_months + 
                      num_of_inquiries_in_last_6_months_excluding_home_auto_loans +
                      outstanding_balance , family = "binomial", data = train_smoted)

# Checking summary of "best_model_6"
summary(best_model_6)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_6))


# Removing num_of_times_60_dpd_or_worse_in_last_12_months due to high vif

best_model_7 <- glm(formula = performance_tag ~ num_of_times_90_dpd_or_worse_in_last_12_months + 
                      avgas_cc_utilization_in_last_12_months + 
                      num_of_pl_trades_opened_in_last_6_months + 
                      num_of_inquiries_in_last_6_months_excluding_home_auto_loans +
                      outstanding_balance , family = "binomial", data = train_smoted)

# Checking summary of "best_model_7"
summary(best_model_7)

# Checking the variance inflation factor to detect the highly correlated independent variable.
sort(vif(best_model_7))

# Final Model for Prediction

final_logistic_model <- best_model_7

##  ----- Perdiction on test data

predictions_logit_test <- predict(final_logistic_model, newdata = test_model_data[, -16], type = "response")

summary(predictions_logit_test)# returns p(bad)


test_model_data$performance_tag <- as.factor(test_model_data$performance_tag)

summary(test_model_data$performance_tag)

test_model_data$probability <- predictions_logit_test

# Let's use the probability cutoff of 50%.
predictions_logit_test_performance <- factor(ifelse(predictions_logit_test >= 0.50, "Yes", "No"))

test_actual_performance <- factor(ifelse(test_model_data$performance_tag==1,"Yes","No"))


table(test_actual_performance,predictions_logit_test_performance)

test_conf <- caret::confusionMatrix(predictions_logit_test_performance, test_actual_performance, positive = "Yes")

test_conf

# Confusion Matrix and Statistics
# Reference
# Prediction    No   Yes
#         No  10380   205
#         Yes  9696   679
# Accuracy : 0.5276          
# Sensitivity : 0.76810         
# Specificity : 0.51704

# Let's Choose the cutoff value. 

perform_fn <- function(cutoff) 
{
  predicted_performance <- factor(ifelse(predictions_logit_test >= cutoff, "Yes", "No"))
  conf <- caret::confusionMatrix(predicted_performance, test_actual_performance, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Summary of test probability

summary(predictions_logit_test)

s = seq(.01,.80,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 


plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(.0,.70,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])< 0.01)]
# 0.5845455
cutoff

# Choosing 0.5845455 for our final model

test_cutoff_performance <- factor(ifelse(predictions_logit_test >=0.5845455, "Yes", "No"))

conf_final <- caret::confusionMatrix(test_cutoff_performance, test_actual_performance, positive = "Yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

acc
# 0.6339695 
sens
# 0.6368778
spec
# 0.6338414

summary(final_logistic_model)
cofficients<-final_logistic_model$coefficients  
cofficients
alpha_beta<-function(basepoints,baseodds,pdo)
{
  beta<-pdo/log(2)
  alpha<-basepoints+beta*log(baseodds)
  return(list(alpha=alpha,beta=beta))
}
x<-alpha_beta(50,0.05,10)
# $alpha
# [1] 6.780719
# $beta
# [1] 14.42695

x

#                                                             Overall
# num_of_times_90_dpd_or_worse_in_last_12_months               7.656052
# avgas_cc_utilization_in_last_12_months                      16.517371
# num_of_pl_trades_opened_in_last_6_months                     3.593427
# num_of_inquiries_in_last_6_months_excluding_home_auto_loans  7.725020
# outstanding_balance                                          7.342341
varImp(final_logistic_model)

##################################################################################################
### KS -statistic - Test Data ######

test_cutoff_performance <- ifelse(test_cutoff_performance=="Yes",1,0)
test_actual_performance <- ifelse(test_actual_performance=="Yes",1,0)


#on testing  data
pred_object_test<- prediction(test_cutoff_performance, test_actual_performance)

performance_measures_test<- ROCR::performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)
#0.27

plotROC(test_model_data$performance_tag, predictions_logit_test)

## Lift Gain Chart :

lift <- function(labels , predicted_prob, groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups)))
  return(gaintable)
}

# Create a Table of cumulative gain and lift 

LG = lift(test_model_data$performance_tag, predictions_logit_test, groups = 10)

# Gain Chart 

plot(LG$bucket,LG$Gain,col="red",type="l",main="Gain Chart",xlab="% of total applications",ylab = "Gain")

# Lift Chart 

plot(LG$bucket,LG$Cumlift,col="red",type="l",main="Lift Chart",xlab="% of total applicants",ylab = "Lift")


View(LG)

# For about 85% applicants will be covered in 6th decile.Check LG$Gain for 6th decile.
# Model_cost => sum of cost of first 12576 records.
# When selecting 60% of the records based on the model, 
# one can expect 1.402715 times the total number of events found by randomly 
# selecting 60%-of-records without a model.



#-------------------------------------------------------------------------------------------------------------------------------
# 5.2 Model Building
#       - Random Forest With Balanced Credit Bureau and Demographic Dataset
#-------------------------------------------------------------------------------------------------------------------------------

RF_data <- woe_data

# Spliting the bank data in 70:30 ratio

set.seed(101)

RF_data$performance_tag <- as.factor(ifelse(RF_data$performance_tag==1,"yes","no"))
split_indices <- sample.split(RF_data$performance_tag, SplitRatio = 0.70)

train_rf <- RF_data[split_indices, ]

test_rf <- RF_data[!split_indices, ]

train_rf_smoted <- SMOTE(performance_tag ~ ., train_rf, perc.over = 600,perc.under=100) 
test_rf_smoted <- SMOTE(performance_tag ~ ., test_rf, perc.over = 600,perc.under=100) 

nrow(train_rf_smoted)/nrow(train_rf)


## Model 

final_random_forest_model_smoted <- randomForest( performance_tag~., data = train_rf_smoted, proximity = F, do.trace = T, mtry = 5)
rf_pred <- predict(final_random_forest_model_smoted, test_rf[, -16], type = "prob")

perform_fn_rf <- function(cutoff) 
{
  predicted_response <- as.factor(ifelse(rf_pred[, 2] >= cutoff, "yes", "no"))
  conf <- caret::confusionMatrix(predicted_response, test_rf$performance_tag, positive = "yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  OUT_rf <- t(as.matrix(c(sens, spec, acc))) 
  colnames(OUT_rf) <- c("sensitivity", "specificity", "accuracy")
  return(OUT_rf)
}


s = seq(0.01,0.2 ,length=100)

OUT_rf = matrix(0,100,3)


for(i in 1:100)
{
  OUT_rf[i,] = perform_fn_rf(s[i])
  
}


# plotting cutoffs

plot(s, OUT_rf[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT_rf[,2],col="darkgreen",lwd=2)
lines(s,OUT_rf[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))

predicted_response <- as.factor(ifelse(rf_pred[, 2] >= 0.50, "yes", "no"))
conf <- caret::confusionMatrix(predicted_response, test_rf$performance_tag, positive = "yes")
conf


cutoff <- s[which(abs(OUT[,1]-OUT[,2])< 0.01)]
cutoff

predicted_response <- as.factor(ifelse(rf_pred[, 2] >= 0.1481818, "yes", "no"))
conf <- caret::confusionMatrix(predicted_response, test_rf$performance_tag, positive = "yes")
conf

# Confusion Matrix and Statistics

#Prediction    no   yes
#no  10471   291
#yes  9605   593

#Accuracy : 0.5279          
#Sensitivity : 0.67081         
#Specificity : 0.52157         

#Create 5 equally size fol
set.seed(101)
folds <- cut(seq(1,nrow(woe_data)),breaks=5,labels=FALSE)
woe_data$performance_tag <- as.factor(woe_data$performance_tag )

library(ranger)
auc_combined <- vector()
for(i in 1:5){
  #Segement your data by fold using the which() function 
  testIndexes <- which(folds==i,arr.ind=TRUE)
  testData <- woe_data[testIndexes, ]
  trainData <- woe_data[-testIndexes, ]
  rf <- ranger(performance_tag ~ ., data = trainData, num.trees = 100,min.node.size = 10, write.forest = TRUE,probability = TRUE,seed=1214133,num.threads = 8)
  fit_test <- predict(rf,data = testData, type = 'response')$predictions[,2]
  pred <- ROCR::prediction(predictions = fit_test,  testData$performance_tag) 
  auc.tmp <- ROCR::performance(pred ,"auc");
  auc_combined <- append(auc_combined,as.numeric(auc.tmp@y.values))
}
sprintf("Auc 5-fold %s", round(mean(auc_combined),2))
# Combined Accuracy after 5-fold cross validation 0.64 which is almost near to logistics regression

# Smoted RF important variables
importance_smoted <- final_random_forest_model_smoted$importance 
importance_smoted <- data.frame(importance_smoted)
importance_smoted

#                                                              MeanDecreaseGini
# num_of_times_90_dpd_or_worse_in_last_6_months                        84.43826
# num_of_times_60_dpd_or_worse_in_last_6_months                        62.77110
# num_of_times_30_dpd_or_worse_in_last_6_months                       192.12516
# num_of_times_90_dpd_or_worse_in_last_12_months                      275.06089
# num_of_times_60_dpd_or_worse_in_last_12_months                      236.76074
# num_of_times_30_dpd_or_worse_in_last_12_months                      216.80487
# avgas_cc_utilization_in_last_12_months                             2265.67785
# num_of_trades_opened_in_last_6_months                               681.90369
# num_of_trades_opened_in_last_12_months                              888.02337
# num_of_pl_trades_opened_in_last_6_months                            638.68506
# num_of_pl_trades_opened_in_last_12_months                          1162.67993
# num_of_inquiries_in_last_6_months_excluding_home_auto_loans         978.24449
# num_of_inquiries_in_last_12_months_excluding_home_auto_loans       1377.25766
# outstanding_balance                                                1636.13166
# total_num_of_trades                                                 932.98304

# -- LG Chart

# Appending the probabilities and response variables to the test data

test_rf$predicted_probs <- rf_pred[, 2]

test_rf$predicted_response <- predicted_response

#---------------------------------------------------------    

# Creating new dataframe "test_predictions_rf"

test_predictions_rf <- test_rf[, c("performance_tag", "predicted_probs", "predicted_response")]
summary(test_predictions_rf$performance_tag)
summary(test_predictions_rf$predicted_response)


response_rate <- table(test$response)[2]/(table(test$response)[1] + table(test$response)[2])

# sorting the probabilities in decreasing order 
test_predictions_rf <- test_predictions_rf[order(test_predictions_rf$predicted_probs, decreasing = T), ]

#Downloading the data 
write.csv(test_predictions_rf,"test_prediction_rf.csv")

summary(test_predictions_rf$performance_tag[1:6800])
summary(test_predictions_rf$predicted_response[1:6800])

# plotting the lift chart

# Loading dplyr package 
require(dplyr)
library(dplyr)

lift <- function(labels , predicted_prob, groups=10) {
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups)))
  return(gaintable)
}

# Create a Table of cumulative gain and lift 

test_predictions_rf$performance_tag <- as.factor(ifelse(test_predictions_rf$performance_tag=="yes",1,0))

LG = lift(test_predictions_rf$performance_tag, test_predictions_rf$predicted_probs, groups = 10)

# Gain Chart 

plot(LG$bucket,LG$Gain,col="red",type="l",main="Gain Chart",xlab="% of total targeted",ylab = "% of positive Response")

# Lift Chart 

plot(LG$bucket,LG$Cumlift,col="red",type="l",main="Gain Chart",xlab="% of total targeted",ylab = "Lift")

# Let's say if you have spent 1Re for each customer
View(LG)


#-------------------------------------------------------------------------------------------------------------------------------
# 5.3 Model Building
#       - Decision Tree With Balanced Credit Bureau and Demographic Dataset
#-------------------------------------------------------------------------------------------------------------------------------

# Classification Trees
library(rpart)
library(rpart.plot)
library(caret)


#1 build tree model- default hyperparameters
tree.model <- rpart(performance_tag ~ .,                     # formula
                    data = train_smoted,                   # training data
                    method = "class")               # classification or regression

# display decision tree
prp(tree.model)

# make predictions on the test set
tree.predict <- predict(tree.model, test_model_data, type = "class")

# evaluate the results
caret::confusionMatrix(test_model_data$performance_tag, tree.predict, positive = "1") 

#Prediction     0     1
#               0 12266  7810
#               1   332   552

#Accuracy : 0.6115          
# Sensitivity : 0.06601         
# Specificity : 0.97365    

#2 Change the algorithm to "information gain" instead of default "gini" ----------------------
tree.model <- rpart(performance_tag ~ .,                     # formula
                    data = train_smoted,                   # training data
                    method = "class",               # classification or regression
                    parms = list(split = "information")
)

# display decision tree
prp(tree.model)

# make predictions on the test set
tree.predict <- predict(tree.model, test_model_data, type = "class")

# evaluate the results
caret::confusionMatrix(test_model_data$performance_tag, tree.predict, positive = "1") 

#     0     1
#0 11139  8937
#1   325   559

# Accuracy : 0.5581          
# Sensitivity : 0.05887         
# Specificity : 0.97165         

#Tuning tree -----------------------------------------------------------------
tree.model <- rpart(performance_tag ~ .,                                # formula
                    data = train_smoted,                             # training data
                    method = "class",                         # classification or regression
                    control = rpart.control(minsplit = 1,     # min observations for node
                                            minbucket = 1,    # min observations for leaf node
                                            cp = 0.001))      # complexity parameter

# display decision tree
prp(tree.model)

# make predictions on the test set
tree.predict <- predict(tree.model, test_model_data, type = "class")

# evaluate the results
caret::confusionMatrix(test_model_data$performance_tag, tree.predict, positive = "1") 

#     0     1
# 0 19063  1013
# 1   833    51

#Accuracy : 0.9119         
#Sensitivity : 0.047932       
#Specificity : 0.958132       


#5 Cross test to choose CP ------------------------------------------------------------
library(caret)

# set the number of folds in cross test to 5
tree.control = trainControl(method = "cv", number = 5)

# set the search space for CP
tree.grid = expand.grid(cp = seq(0, 0.02, 0.0025))

# train model
library(doParallel)
cl <- makeCluster(4)
registerDoParallel(cl)
tree.model <- caret::train(performance_tag ~ .,
                           data = train_smoted,
                           method = "rpart",
                           metric = "Accuracy",
                           trControl = tree.control,
                           tuneGrid = tree.grid,
                           control = rpart.control(minsplit = 50,
                                                   minbucket = 20))

stopCluster(cl)

# look at cross validated model results
tree.model

# look at best value of hyperparameter
tree.model$bestTune

# make predictions on test set
tree.predict <- predict.train(tree.model, test_model_data)

# accuracy
conf <- caret::confusionMatrix(tree.predict, test_model_data$performance_tag)  

conf

#     0     1
#0 17477   735
#1  2599   149

#Accuracy : 0.8409          
#Sensitivity : 0.87054         
#Specificity : 0.16855         

# This model is achieved with high accuracy and sensitivity but very less specificity, hence not reliable

# plot CP vs Accuracy
accuracy_graph <- data.frame(tree.model$results)
ggplot(data = accuracy_graph, aes(x = cp, y = Accuracy*100)) +
  geom_line() +
  geom_point() +
  labs(x = "Complexity Parameter (CP)", y = "Accuracy", title = "CP vs Accuracy")


#-------------------------------------------------------------------------------------------------------------------------------
# 6. Scorecard Development
#-------------------------------------------------------------------------------------------------------------------------------

# We decided to use logistic regression for Scorecard creation as we found it the most balanced model

predictions_logit_woe <- predict(final_logistic_model, newdata = woe_data[, -16], type = "response")

woe_cutoff_performance <- factor(ifelse(predictions_logit_test >=0.5845455, "Yes", "No"))

df_score <- woe_data

df_score$perdict_default <- as.data.frame(predictions_logit_woe)

df_score$predict_NonDefault <- 1 - df_score$perdict_default

df_score$odds <-  log(df_score$predict_NonDefault/df_score$perdict_default)

# Score = Offset + ( Factor * log(odds) )
# Factor = PDO/ln(2)
# Offset = Score-(Factor*log(odds))

# In our case, PDO = 20, Base Score=400 & odds = 10


Factor = 20/log(2)
#28.8539

# 333.5614
Offset = 400 - (28.8539*log(10))

df_score$Score = Offset + (28.8539*df_score$odds)

View(df_score)

#write.csv(df_score$performance_tag, "perf.csv")
#write.csv(df_score$Score$predictions_logit_test, "score.csv")
plot(df_score$performance_tag, df_score$Score$predictions_logit_woe)

hist(df_score$Score$predictions_logit_woe)
d <- density(df_score$Score$predictions_logit_woe)
plot(d)
plot(df_score$Score$predictions_logit_woe, type='l')
summary(df_score$Score$predictions_logit_woe)

## This Score is the basis for deciding whether to aquire customer or not.

#-------------------------------------------------------------------------------------------------------------------------------
# 7. Analysis of Non Approved Applicants and benefits
#-------------------------------------------------------------------------------------------------------------------------------

# data frame with NA's performance tag

final_data_set_with_na <- credx_master_data_with_na[,colnames(credx_master_data_with_na) %in% k1]

final_data_set_with_na <- cbind(final_data_set_with_na,credx_master_data_with_na[,29])
colnames(final_data_set_with_na)[16] <- "performance_tag"

woe_table_na <- final_data_set_with_na

# Now, let's replace the variables with woe value for model building 
matrix_1 <- list()

for(i in 1 :15) {
  
  matrix_1[[i]] = cbind(IV_1$Tables[[i]][1],IV_1$Tables[[i]][4])
  
}

empty_matrix <- matrix(0,nrow(final_data_set_with_na),ncol(final_data_set_with_na))

for(i in 1:ncol(final_data_set_with_na[,-16]))
{
  
  empty_matrix[,i] = woe_function(matrix_1[[i]],final_data_set_with_na[,i])  
  
}


woe_data_with_na <- data.frame(empty_matrix)

for(i in 1:ncol(woe_data_with_na)){
  
  colnames(woe_data_with_na)[i] <- colnames(final_data_set_with_na)[i]
  
}


woe_data_with_na$performance_tag <- final_data_set_with_na$performance_tag

# Convert performance_tag to factor
woe_data_with_na$performance_tag <- as.factor(woe_data_with_na$performance_tag)

predictions_logit_na <- predict(final_logistic_model, newdata = woe_data_with_na[, -16], type = "response")

na_performance <- factor(ifelse(predictions_logit_na >=0.5845455, "Yes", "No"))

woe_data_with_na$performance_tag <- na_performance

round(prop.table(table(woe_data_with_na$performance_tag))*100) 

summary(woe_data_with_na$performance_tag)

# The above analysis indicates that the model out of the total population
# 94% of the rejected applicants will default. Only 6% will not.
# So effectively we can extent credit to 92 (i.e. 6%) applicants out of 1425 rejected population


