####################################################################################
########################### Case Study  : Retail-Giant Sales Forecasting          ##
########################### Roll Number : DDA1710161                              ##
########################### Batch       : PG Diploma in Data Analytics March 2017 ##
####################################################################################

############################ Retail-Giant Sales Forecasting ########################
# 1. Business Understanding
# 2. Data Understanding and EDA
# 3. Data Preparation
# 4. Model Building and Evaluation
# 5. Conclusion/Summary 
########################################################################################
# 1. Business Understanding and Problem Statement: 
########################################################################################
#"Global Mart" is an online store super giant having worldwide operations. It takes 
# orders and delivers across the globe and deals with all the major product categories
# which are - consumer, corporate & home office. you want to forecast the sales and 
# the demand for the next 6 months, that would help you manage the revenue and inventory
# accordingly.

# Loading required libraries
#-------------------------------------------------

library(graphics)
library(forecast)
library(plyr)
library(reshape2)
library(lubridate)
library(dplyr)
library(raster)
library(TTR)

# Loading data
#-------------------------------------------------

globalSales <- read.csv("Global Superstore.csv",header = T, stringsAsFactors = F)

#####################################################################################
# 2. Data Understanding and EDA
#####################################################################################

# Understanding Dimensions
#----------------------------
dim(globalSales) #51290 obs. of  24 variables

# Structure of the dataset
#----------------------------
str(globalSales) #51290 obs. of  24 variables

#printing first few rows
#----------------------------
head(globalSales)

#Exploring the data
#----------------------------
summary(globalSales)

# NA values in dataset
#----------------------------
sum(is.na(globalSales)) # 41296 null values

# Check duplicate data
#----------------------------
nrow(globalSales) - nrow(unique(globalSales)) # 0 - No need to remove any record at this moment

# Identifying columns and missing data percentage

data=globalSales
ncol=rep(nrow(data) ,each=ncol(data))
missingdata=as.data.frame(cbind(colnames=names(data),ncol,nmsg=as.integer(as.character(as.vector(apply(data, 2, function(x) length(which(is.na(x)))))))))
missingdata$nmsg=as.numeric(levels(missingdata$nmsg))[missingdata$nmsg]

View(missingdata) # Since missing data is only in Postal code so need need to worry about "NA" treatment

#####################################################################################
# 3. Data Preparation
#####################################################################################

# Remove columns that have unique values - No unique values
#----------------------------------------------------------
col_unique_value = sapply(globalSales, function(x) length(unique(x)))

cat("Constant feature count:", length(col_unique_value[col_unique_value==1])) # Constant feature count: 0

names(col_unique_value[col_unique_value==1])

# Drop cases with no row id
#--------------------------
globalSales <-subset(globalSales,!is.na(globalSales$Row.ID))

# Create a data frame with nessary fields from master globalSales data
#----------------------------------------------------------------------
sales <- data.frame(globalSales$Order.Date,globalSales$Segment,globalSales$Market,globalSales$Sales,globalSales$Quantity, globalSales$Profit)
colnames(sales) <- c("OrderDate","Segment","Market","Sales","Quantity","Profit")

# Create a data frame with nessary fields for finding coefficient of variation
#------------------------------------------------------------------------------
str(sales)

# Checking min max and mean values no invalid values seen
#------------------------------------------------------------------------------
summary(sales)  

# Add new column with Year-month
#------------------------------------------------------------------------------
sales$OrderDate <- as.Date(sales$OrderDate, "%d-%m-%Y") 
sales$OrderMonth<- paste(strftime(sales$OrderDate,"%Y") ,strftime(sales$OrderDate,"%m"),sep = "-" )
sales$OrderMonth <- as.Date(paste(sales$OrderMonth,"-01",sep=""))


# Aggregate Sales data at Month level and find segmnets with least CV for profit
#--------------------------------------------------------------------------------

sales <-sales[ ,-1]
Sales_Total_Month <- aggregate(.~ Segment+Market+OrderMonth,sales,FUN = sum)
Sales_Total <- Sales_Total_Month[,-3]
Sales_Mean  <- aggregate(.~ Segment+Market,Sales_Total,FUN = mean)
Sales_SD    <- aggregate(.~ Segment+Market,Sales_Total,FUN =sd )
Sales_CV    <- cbind(Sales_Mean,Sales_SD$Profit)
Sales_CV$CV <- (Sales_CV$`Sales_SD$Profit`/Sales_CV$Profit)*100
Sales_CV    <- Sales_CV[order(Sales_CV[ ,7]), ]

# Above analysis concludes 2 most profitable and consistently profitable segments are : 
# 1)EU Consumer
# 2)APAC Consumer


# Extract Sales total, quantity and profit for EU Consumer,APAC Consumer
#--------------------------------------------------------------------------------

EUConsumerTotals  <- Sales_Total_Month[(Sales_Total_Month$Segment=="Consumer" & Sales_Total_Month$Market=="EU"), ]

APACConsumerTotals <- Sales_Total_Month[(Sales_Total_Month$Segment=="Consumer" & Sales_Total_Month$Market=="APAC"), ] 


########################################################################################
# 4. Model Building and Evaluation
########################################################################################

# Time series for EU Consumer total sales
EUSalesTS <- ts(EUConsumerTotals$Sales,frequency=12,start=c(2011,1),end=c(2014,12))

# Decomposition of TS
decomposedEUSalesTS <- decompose(EUSalesTS)
plot(decomposedEUSalesTS) 

# Both Seasonality and Trend seen. Seasonality is additive in nature without much variation with time 
plot(EUSalesTS, xlab="Time",ylab="Sales",lwd=3,col='blue')

# smoothebEUConsumer average window size 4
smoothebEUConsumer <- stats::filter(EUSalesTS,filter=rep(1/4,4), method='convolution',sides = 2)
lines(smoothebEUConsumer,col='red',lwd=3)
# Smoothed timeseries indicating slight upward trend#

# Form a regression model form a data frame of the smoothed series which includes the "month"

smoothedEUConsumer<-data.frame(cbind(c(1:48),smoothebEUConsumer))
colnames(smoothedEUConsumer)<-c("month","sales")

# Fill missing data points for 1st, 47th  and 48th 
smoothedEUConsumer$sales[1] <- smoothedEUConsumer$sales[2]- (smoothedEUConsumer$sales[3] - smoothedEUConsumer$sales[2])
smoothedEUConsumer$sales[47] <- smoothedEUConsumer$sales[46]+ (smoothedEUConsumer$sales[46] - smoothedEUConsumer$sales[45])
smoothedEUConsumer$sales[48] <- smoothedEUConsumer$sales[47]+ (smoothedEUConsumer$sales[47] - smoothedEUConsumer$sales[46])


# Convert smoothed curve to time series
smoothedEUConsumerSales <- ts(smoothedEUConsumer$sales,frequency=12,start=c(2011,1),end=c(2014,12))

lines(smoothedEUConsumerSales,col='red',lwd=2)

# Divide  time series into training and test sets Extract last 6 months for test
EUconsumerTrain <- window(smoothedEUConsumerSales,start = c(2011,1),end=c(2014,6))
EUconsumerTest <- window(smoothedEUConsumerSales,start=c(2014,7), end=c(2014,12))


plot(EUconsumerTrain)
plot(EUconsumerTest)

# Fit linear model with time series
EUConsumerSalesTslm <- tslm (EUconsumerTrain~trend+I(sin(0.5*trend/2))+season)

summary(EUConsumerSalesTslm) 
# Model with Adjusted R-Squared value of 0.89

# Forecast for the next 6 months
EUConsumerSalesTslmForecast <- forecast(EUConsumerSalesTslm,h=6,level=0)
plot(smoothedEUConsumerSales,ylab="Sales",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(EUConsumerSalesTslmForecast$fitted,lwd=4,col="green",lty=3)
lines(EUConsumerSalesTslmForecast$mean,col="red",lwd=4)

#Plot shows Forecasted values are close to Actual values

EUConsumerSalesMAPE <- accuracy(EUConsumerSalesTslmForecast$mean,EUconsumerTest) 
EUConsumerSalesMAPE #MAPE 8.015554

#acf
acf(EUConsumerSalesTslmForecast$residuals,lag.max = 12) 
acf(EUConsumerSalesTslmForecast$residuals,lag.max = 12, type="partial")
#acf test indicating residuals are white Noise

# Fit best ARIMA model to univariate time series
arimaEUSalesTS <- auto.arima(EUconsumerTrain)
summary(arimaEUSalesTS)

#Forecasting time series for next 6 months
ArimaForecast <- forecast(arimaEUSalesTS,h=6)
plot(smoothedEUConsumerSales,ylab="Sales",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(ArimaForecast$fitted,lwd=4,col="green",lty=3)
lines(ArimaForecast$mean,col="red",lwd=4)
# Plot from Arima Model also indicating forecasted values close to actual values

# Accuracy measures for a forecast model
ArimaMAPE1 <- accuracy(ArimaForecast,EUconsumerTest)
ArimaMAPE1

# MAPE for test is 10.454372 , which shows that tslm is a better model than auto ARIMA

# End of time series for EU Consumer total sales

#-------------------------------------------------------------------------------------------

# Time series for EU Consumer total Quantity

EUQuantityTS <- ts(EUConsumerTotals$Quantity,frequency=12,start=c(2011,1),end=c(2014,12))

# Decomposition of Time Series
decomposedEUQuantityTS <- decompose(EUQuantityTS)

plot(decomposedEUQuantityTS)
# Trend and seasonality of additive nature seen

plot(EUQuantityTS, xlab="Time",ylab="Quantity",lwd=3,col='blue')

# SmoothebEUConsumer average window size 4
smoothedEUConsumerQnty <- stats::filter(EUQuantityTS,filter=rep(1/4,4), method='convolution',sides = 2)
lines(smoothedEUConsumerQnty,col='red',lwd=3)

# Form a regression model form a data frame of the smoothed series which includes the "month"

smoothedEUConsumerQntyDF<-data.frame(cbind(c(1:48),smoothedEUConsumerQnty))
colnames(smoothedEUConsumerQntyDF)<-c("month","quantity")


# Fill missing data points for 1st, 47th  and 48th 
smoothedEUConsumerQntyDF$quantity[1] <- smoothedEUConsumerQntyDF$quantity[2]- (smoothedEUConsumerQntyDF$quantity[3] - smoothedEUConsumerQntyDF$quantity[2])
smoothedEUConsumerQntyDF$quantity[47] <- smoothedEUConsumerQntyDF$quantity[46]+ (smoothedEUConsumerQntyDF$quantity[46] - smoothedEUConsumerQntyDF$quantity[45])
smoothedEUConsumerQntyDF$quantity[48] <- smoothedEUConsumerQntyDF$quantity[47]+ (smoothedEUConsumerQntyDF$quantity[47] - smoothedEUConsumerQntyDF$quantity[46])

# Convert smoothed curve to time series
smoothedEUConsumerQty <- ts(smoothedEUConsumerQntyDF$quantity,frequency=12,start=c(2011,1),end=c(2014,12))
lines(smoothedEUConsumerQty,col='red',lwd=2)

# Divide  time series into training and test sets

# Keep last 6 months for test 
EUconsumerQtyTrain <- window(smoothedEUConsumerQty,start = c(2011,1),end=c(2014,6))
EUconsumerQtyTest <- window(smoothedEUConsumerQty,start=c(2014,7), end=c(2014,12))

# Plots
plot(EUconsumerQtyTrain)
plot(EUconsumerQtyTest)

# Fit linear model with time series
EUConsumerQntyTslm <- tslm (EUconsumerQtyTrain~trend+I(sin(0.5*trend/2))+season)
summary(EUConsumerQntyTslm)
##Model With Adjusted R square of 0.95###

# Forecast for the next 6 months
EUConsumerQntyTslmForecast <- forecast(EUConsumerQntyTslm,h=6,level=0)
plot(smoothedEUConsumerQty,ylab="Quantity",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(EUConsumerQntyTslmForecast$fitted,lwd=4,col="green",lty=3)
lines(EUConsumerQntyTslmForecast$mean,col="red",lwd=4)

EUConsumerQntyMAPE <- accuracy(EUConsumerQntyTslmForecast$mean,EUconsumerQtyTest) 
EUConsumerQntyMAPE # MAPE 13.6492

#acf
acf(EUConsumerQntyTslmForecast$residuals,lag.max = 12) 
acf(EUConsumerQntyTslmForecast$residuals,lag.max = 12, type="partial")

#acf test indicates residual is white Noise###

# Fit best ARIMA model to univariate time series
arimaEUSalesTS <- auto.arima(EUconsumerQtyTrain)
summary(arimaEUSalesTS)


# Forecasting time series for next 6 months
ArimaForecast <- forecast(arimaEUSalesTS,h=6)
plot(smoothedEUConsumerQty,ylab="Quantity",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(ArimaForecast$fitted,lwd=4,col="green",lty=3)
lines(ArimaForecast$mean,col="red",lwd=4)
# Plot from Arima Model also indicating forecasted values close to actual values


# Accuracy measures for a forecast model
ArimaEUPE1 <- accuracy(ArimaForecast,EUconsumerQtyTest)
ArimaEUPE1 #MAPE 13.012042

# MAPE of auto ARMA is 13.012042 , which is pretty much equalent to model by tslm which has MAPE of 13.6492##

# End of time series for EU Consumer total Quantity
#-------------------------------------------------------------------------------------------

# Time series for APAC Consumer total sales

APACSalesTS <- ts(APACConsumerTotals$Sales,frequency=12,start=c(2011,1),end=c(2014,12))

decomposedAPACSalesTS <- decompose(APACSalesTS)

plot(decomposedAPACSalesTS)
# Trend and seasonality of additive nature seen

plot(APACSalesTS, xlab="Time",ylab="Sales",lwd=3,col='blue')

#smoothebAPACConsumer average window size 4
smoothebAPACConsumer <- stats::filter(APACSalesTS,filter=rep(1/4,4), method='convolution',sides = 2)
lines(smoothebAPACConsumer,col='red',lwd=3)

# Form a regression model form a data frame of the smoothed series which includes the "month"

smoothedAPACConsumer<-data.frame(cbind(c(1:48),smoothebAPACConsumer))
colnames(smoothedAPACConsumer)<-c("month","sales")


# Fill missing data points for 1st, 47th  and 48th 

smoothedAPACConsumer$sales[1] <- smoothedAPACConsumer$sales[2]- (smoothedAPACConsumer$sales[3] - smoothedAPACConsumer$sales[2])
smoothedAPACConsumer$sales[47] <- smoothedAPACConsumer$sales[46]+ (smoothedAPACConsumer$sales[46] - smoothedAPACConsumer$sales[45])
smoothedAPACConsumer$sales[48] <- smoothedAPACConsumer$sales[47]+ (smoothedAPACConsumer$sales[47] - smoothedAPACConsumer$sales[46])

# Convert smoothed curve to time series
smoothedAPACConsumerSales <- ts(smoothedAPACConsumer$sales,frequency=12,start=c(2011,1),end=c(2014,12))
lines(smoothedAPACConsumerSales,col='red',lwd=2)

# Divide  time series into training and test sets

# Keep last 6 months for test 
APACconsumerTrain <- window(smoothedAPACConsumerSales,start = c(2011,1),end=c(2014,6))
APACconsumerTest <- window(smoothedAPACConsumerSales,start=c(2014,7), end=c(2014,12))

# Plots
plot(APACconsumerTrain)
plot(APACconsumerTest)

# Fit linear model with time series
APACConsumerSalesTslm <- tslm (APACconsumerTrain~trend+I(sin(0.75*trend/2))+season)
summary(APACConsumerSalesTslm)

# Forecast for the next 6 months
APACConsumerSalesTslmForecast <- forecast(APACConsumerSalesTslm,h=6,level=0)
plot(smoothedAPACConsumerSales,ylab="Sales",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(APACConsumerSalesTslmForecast$fitted,lwd=4,col="green",lty=3)
lines(APACConsumerSalesTslmForecast$mean,col="red",lwd=4)

APACConsumerSalesMAPE <- accuracy(APACConsumerSalesTslmForecast$mean,APACconsumerTest) 
APACConsumerSalesMAPE #MAPE 7.46393

#acf
acf(APACConsumerSalesTslmForecast$residuals,lag.max = 12) 
acf(APACConsumerSalesTslmForecast$residuals,lag.max = 12, type="partial")

# Fit best ARIMA model to univariate time series
arimaAPACSalesTS <- auto.arima(APACconsumerTrain)

# Forecasting time series for next 6 months
ArimaForecast <- forecast(arimaAPACSalesTS,h=6)
plot(smoothedAPACConsumerSales,ylab="Sales",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(ArimaForecast$fitted,lwd=4,col="green",lty=3)
lines(ArimaForecast$mean,col="red",lwd=4)

# Accuracy measures for a forecast model
ArimaMAPE1 <- accuracy(ArimaForecast,APACconsumerTest)
ArimaMAPE1 #MAPE 10.146732

# MAPE for test is 10.146732 , which shows that tslm is a better model than auto ARIMA

# End of time series for APAC Consumer total sales
#----------------------------------------------------------------------------------------

# Time series for APAC Consumer total Quantity

APACQuantityTS <- ts(APACConsumerTotals$Quantity,frequency=12,start=c(2011,1),end=c(2014,12))

decomposedAPACQuantityTS <- decompose(APACQuantityTS)

plot(decomposedAPACQuantityTS)
# Trend and Additive seasonality seen##

plot(APACQuantityTS, xlab="Time",ylab="Sales",lwd=3,col='blue')

#smoothebAPACConsumer average window size 4
smoothedAPACConsumerQnty <- stats::filter(APACQuantityTS,filter=rep(1/4,4), method='convolution',sides = 2)
lines(smoothedAPACConsumerQnty,col='red',lwd=3)

# Form a regression model form a data frame of the smoothed series which includes the "month"

smoothedAPACConsumerQntyDF<-data.frame(cbind(c(1:48),smoothedAPACConsumerQnty))
colnames(smoothedAPACConsumerQntyDF)<-c("month","quantity")

# Fill missing data points for 1st, 47th  and 48th 
smoothedAPACConsumerQntyDF$quantity[1] <- smoothedAPACConsumerQntyDF$quantity[2]- (smoothedAPACConsumerQntyDF$quantity[3] - smoothedAPACConsumerQntyDF$quantity[2])
smoothedAPACConsumerQntyDF$quantity[47] <- smoothedAPACConsumerQntyDF$quantity[46]+ (smoothedAPACConsumerQntyDF$quantity[46] - smoothedAPACConsumerQntyDF$quantity[45])
smoothedAPACConsumerQntyDF$quantity[48] <- smoothedAPACConsumerQntyDF$quantity[47]+ (smoothedAPACConsumerQntyDF$quantity[47] - smoothedAPACConsumerQntyDF$quantity[46])

# Convert smoothed curve to time series
smoothedAPACConsumerQty <- ts(smoothedAPACConsumerQntyDF$quantity,frequency=12,start=c(2011,1),end=c(2014,12))
lines(smoothedAPACConsumerQty,col='red',lwd=2)

# Divide  time series into training and test sets

# Keep last 6 months for test 
APACconsumerQtyTrain <- window(smoothedAPACConsumerQty,start = c(2011,1),end=c(2014,6))
APACconsumerQtyTest <- window(smoothedAPACConsumerQty,start=c(2014,7), end=c(2014,12))

# Plots
plot(APACconsumerQtyTrain)
plot(APACconsumerQtyTest)

# Fit linear model with time series
APACConsumerQntyTslm <- tslm (APACconsumerQtyTrain~trend+I(sin(0.75*trend/2))+season)
summary(APACConsumerQntyTslm)
##Adjusted R suqare of 0.94##

# Forecast for the next 6 months
APACConsumerQntyTslmForecast <- forecast(APACConsumerQntyTslm,h=6,level=0)
plot(smoothedAPACConsumerQty,ylab="Sales",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(APACConsumerQntyTslmForecast$fitted,lwd=4,col="green",lty=3)
lines(APACConsumerQntyTslmForecast$mean,col="red",lwd=4)
##PLot showing Forecast and actual values are close###
APACConsumerQntyMAPE <- accuracy(APACConsumerQntyTslmForecast$mean,APACconsumerQtyTest) 
APACConsumerQntyMAPE # MAPE 12.12928

#acf
acf(APACConsumerQntyTslmForecast$residuals,lag.max = 12) 
acf(APACConsumerQntyTslmForecast$residuals,lag.max = 12, type="partial")
#acf test shows residuals are white noise###

# Fit best ARIMA model to univariate time series
arimaAPACQtyTS <- auto.arima(APACconsumerQtyTrain)

# Forecasting time series for next 6 months
ArimaForecast <- forecast(arimaAPACQtyTS,h=6)
plot(smoothedAPACConsumerQty,ylab="Quantity",xlab="Time", col="blue",lwd=4)  
axis(1,at=seq(2011,2014,1),labels=format(seq(2011,2014,1)))
lines(ArimaForecast$fitted,lwd=4,col="green",lty=3)
lines(ArimaForecast$mean,col="red",lwd=4)

# Accuracy measures for a forecast model
ArimaMAPE1 <- accuracy(ArimaForecast,APACconsumerQtyTest)
ArimaMAPE1

# MAPE of auto ARMA is 18.06362 , whereas MAPE for Tslm is 12.1292 Hence tslm is better than autoarima#

# End of time series for APAC Consumer total Quantity
#---------------------------------------------------------------------------------------
########################################################################################
# 5. Conclusion/Summary 
########################################################################################
# Summary :
#---------------------------------------------------------------------------------------
#  Model           MAPE TSLM       MAPE AUTOArima    Better Model
#  EUTOtalSales     8.01            10.45             TSLM
#  EUTOtalQty       13.64           13.01             Equally good  
#  APTotalSales     7.46            10.14             TSLM 
#  APTotalQty       12.12           18.06             TSLM 
#---------------------------------------------------------------------------------------
# Conclusion: 
#---------------------------------------------------------------------------------------
# With the given dataset and problem statement after doing analysis we found that
# seasonality and trend exist for EU Consumer and APAC Consumer segments.
# We found that for forecasting next 6 months Sales and Quantity modeling with
# classical decomposition works well for all scenarios and it is better than Auto ARIMA. 
########################################################################################



