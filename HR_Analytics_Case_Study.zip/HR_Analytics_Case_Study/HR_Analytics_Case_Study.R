#-----------------------Group Case Study HR Analytics-----------------------------------------

#-------------------------------------------------------------------------------------------
# loading the required libraries
library(car)
library(caret)
library(caTools)
library(corrplot)
library(cowplot)
require(dplyr)
library(dplyr)
library(e1071)
library(GGally)
library(ggplot2)
library(grid)
library(gridExtra)
library(lubridate)
library(MASS)
library(ROCR)
library(scales)
library(stargazer)
library(tidyr)
library(progress)

#-------------------------------------------------------------------------------------------
options("scipen"=100, "digits"=4)

# set working directory - remove when submitting solution
#setwd("D:/Personal/Abhishek/IIIT B Upgrad/Main-Course/Module3/casestudy")

#-------------------------------------------------------------------------------------------
# Employee General data
empgeneral <- read.csv("general_data.csv",header = TRUE, stringsAsFactors = FALSE, check.names=FALSE)
# Employee survey data
empsurvey <- read.csv("employee_survey_data.csv",header = TRUE, stringsAsFactors = FALSE, check.names=FALSE)
# in_time
empintime <- read.csv("in_time.csv",header = TRUE, stringsAsFactors = FALSE, check.names=FALSE)
# out_time
empouttime <- read.csv("out_time.csv",header = TRUE, stringsAsFactors = FALSE, check.names=FALSE)
# manager survey data
mgrsurvey <- read.csv("manager_survey_data.csv",header = TRUE, stringsAsFactors = FALSE, check.names=FALSE)

str(empgeneral)    # 4410 obs of 24 variables including the target variable
str(empsurvey)     # 4410 obs of 4 variables
str(empintime)     # 4410 obs of 262 variables
str(empouttime)    # 4410 obs of 262 variables
str(mgrsurvey)     # 4410 obs of 3 variables

# Collate the data together in one single file
length(unique(tolower(empgeneral$EmployeeID)))    # 4410, confirming EmployeeID is key 
length(unique(tolower(empsurvey$EmployeeID)))     # 4410, confirming EmployeeID is key

# Missing EmployeeID in empintime, empouttime data frames
colnames(empintime)[1]  <- 'EmployeeID'
colnames(empouttime)[1] <- 'EmployeeID'

length(unique(tolower(empintime$EmployeeID)))     # 4410, confirming EmployeeID is key
length(unique(tolower(empouttime$EmployeeID)))    # 4410, confirming EmployeeID is key
length(unique(tolower(mgrsurvey$EmployeeID)))     # 4410, confirming EmployeeID is key

setdiff(empgeneral$EmployeeID,empsurvey$EmployeeID)     # Identical EmployeeID across these datasets
setdiff(empgeneral$EmployeeID,empintime$EmployeeID)     # Identical EmployeeID across these datasets
setdiff(empgeneral$EmployeeID,empouttime$EmployeeID)    # Identical EmployeeID across these datasets
setdiff(empgeneral$EmployeeID,mgrsurvey$EmployeeID)     # Identical EmployeeID across these datasets


#-------------------------------------------------------------------------------------------
# getting meaningful information from in_time.csv, out_time.csv

# Changed from WIDE format to LONG format
empintimewide <- gather(empintime,in_date,in_tm,c(2:262))
empouttimewide <- gather(empouttime,out_date,out_tm,c(2:262))

# coverting empintime to wide format
empintimewide$EmployeeID[!(empintimewide$EmployeeID %in% empouttimewide$EmployeeID)]
empintimewide$in_date[!(empintimewide$in_date %in% empouttimewide$out_date)]
# converting empouttime to wide format
empouttimewide$EmployeeID[!(empouttimewide$EmployeeID %in% empintimewide$EmployeeID)]
empouttimewide$out_date[!(empouttimewide$out_date %in% empintimewide$in_date)]

# Merged after confirming data is in sync in both files
merged_df <- cbind(empintimewide, empouttimewide)

# Caluculated attendance hour
merged_df$attendance <- as.POSIXct(as.matrix(merged_df$out_tm), format="%Y-%m-%d %H:%M:%S") - as.POSIXct(as.matrix(merged_df$in_tm), format="%Y-%m-%d %H:%M:%S")

# Removed duplicate EmployeeID field
merged_df[4] <- NULL

# Extracted Month
merged_df$month <- month(merged_df$in_date)

# Extracted Year
merged_df$year <- year(merged_df$in_date)

# Calculated average attendance and leaves for year
# mean attendance per employeeid / year
empyrleave <- merged_df %>%         
  group_by(year, EmployeeID) %>%   # group data by Year & employeeid
  summarize(MeanYrAttendance = round(mean(attendance, na.rm = TRUE),0), AnnualLeave = sum(is.na(attendance)))

# taking only mean_year, total_annual_leave
empyrleave <- empyrleave[ , c(2,3,4)]

#-------------------------------------------------------------------------------------------
# merging the  frames empgeneral, empsurvey, mgrsurvey
empmaster <- Reduce(function(...) merge(..., all=TRUE), list(empgeneral, empsurvey, mgrsurvey, empyrleave))

empmaster$AnnualLeave <- as.numeric(empmaster$AnnualLeave)
empmaster$MeanYrAttendance <- as.numeric(empmaster$MeanYrAttendance)


#---------------------------------------- Data Cleanup --------------------------------------------------

######### Descriptive statistics Using Stargazer package #######################
stargazer(empmaster, type = "text", title="Descriptive statistics", digits = 2, out="DescriptiveStat.txt")

# Understanding the structure of the collated file
str(empmaster) # 4410 obs. of  31 variables;

# check NA's for empgeneral
# NumCompaniesWorked, TotalWorkingYears, EnvironmentSatisfaction, JobSatisfaction, WorkLifeBalance - could be fresher with no experience as an employee
empmaster %>%  summarise_all(funs(sum(is.na(.)))) 
sum(is.na(empmaster))
#write.csv(empmaster, "empmaster.csv")

# Replace NA's with 0
# NumCompaniesWorked
na_indices <- which(is.na(empmaster$NumCompaniesWorked == T))
empmaster$NumCompaniesWorked[na_indices] <- 0
# TotalWorkingYears
na_indices <- which(is.na(empmaster$TotalWorkingYears == T))
empmaster$TotalWorkingYears[na_indices] <- 0
# EnvironmentSatisfaction
na_indices <- which(is.na(empmaster$EnvironmentSatisfaction == T))
empmaster$EnvironmentSatisfaction[na_indices] <- 0

# Total Work Years Group
na_indices <- which(is.na(empmaster$TotalWorkYearsGroup == T))
empmaster$TotalWorkYearsGroup[na_indices] <- 0

# Number of Companies Worked Group
na_indices <- which(is.na(empmaster$NumOfCompWorkedGroup == T))
empmaster$NumOfCompWorkedGroup[na_indices] <- 0


#### Using function for Mode

columnmode <- function(x, na.rm = FALSE) {
  if(na.rm){
    x = x[!is.na(x)]
  }
  
  uniquex <- unique(x)
  return(uniquex[which.max(tabulate(match(x, uniquex)))])
}
# Replacing NA's with mode

# EnvironmentSatisfaction
na_indices <- which(is.na(empmaster$EnvironmentSatisfaction == T))
empmaster$EnvironmentSatisfaction[na_indices] <- columnmode(empmaster$EnvironmentSatisfaction)

# JobSatisfaction
na_indices <- which(is.na(empmaster$JobSatisfaction == T))
empmaster$JobSatisfaction[na_indices] <- columnmode(empmaster$JobSatisfaction)

# WorkLifeBalance
na_indices <- which(is.na(empmaster$WorkLifeBalance == T))
empmaster$WorkLifeBalance[na_indices] <- columnmode(empmaster$WorkLifeBalance)                                                      


# Check NA's after treatment
sum(is.na(empmaster)) # 0

# Identifying columns and missing data percentage
data=empmaster
ncol=rep(nrow(data) ,each=ncol(data))
missingdata=as.data.frame(cbind(colnames=names(data),ncol,nmsg=as.integer(as.character(as.vector(apply(data, 2, function(x) length(which(is.na(x)))))))))
missingdata$nmsg=as.numeric(levels(missingdata$nmsg))[missingdata$nmsg]

missingdata=cbind(missingdata,percmissing=as.integer(missingdata$nmsg/ncol*100))

# Look for Duplicate EmployeeIDs
nrow(empmaster)
length(unique(empmaster$EmployeeID))

# Calculating hours spent by employee
empmaster$OfficeHrSpent <- empmaster$StandardHours - empmaster$MeanYrAttendance

empmaster$OfficeHrSpent <- ifelse(empmaster$OfficeHrSpent  == 0, "normal-time", ifelse(empmaster$OfficeHrSpent < 0 , "over-time", "under-time"))

# Creating Age Groups
empmaster$AgeGroup <- with(empmaster,ifelse(Age>55,8,ifelse(Age>50,7,ifelse(Age>45,6,ifelse(Age>40,5,ifelse(Age>35,4,ifelse(Age>30,3,ifelse(Age>25,2,1)))))))) 

# Distance From Home Group
empmaster$DistanceGroup <- with(empmaster,ifelse(DistanceFromHome>25,6,ifelse(DistanceFromHome>20,5,ifelse(DistanceFromHome>15,4,ifelse(DistanceFromHome>10,3,ifelse(DistanceFromHome>5,2,1)))))) 

# Years With Manager Group
empmaster$YearsWithManagerGroup <- with(empmaster,ifelse(YearsWithCurrManager>15,5,ifelse(YearsWithCurrManager>10,4,ifelse(YearsWithCurrManager>5,3,ifelse(YearsWithCurrManager>2,2,1))))) 

# Working Years Group
empmaster$TotalWorkYearsGroup <- with(empmaster,ifelse(TotalWorkingYears>35,9,ifelse(TotalWorkingYears>30,8,ifelse(TotalWorkingYears>25,7,ifelse(TotalWorkingYears>20,6,ifelse(TotalWorkingYears>15,5,ifelse(TotalWorkingYears>10,4,ifelse(TotalWorkingYears>5,3,ifelse(TotalWorkingYears>2,2,1)))))))))

# Number of Companies Worked Group
empmaster$NumOfCompWorkedGroup <- with(empmaster,ifelse(NumCompaniesWorked>4,3,ifelse(NumCompaniesWorked>2,2,1))) #Creating Number of Companies Worked

# Years at Company
empmaster$YearsAtCompanyGroup <- with(empmaster,ifelse(YearsAtCompany>35,9,ifelse(YearsAtCompany>30,8,ifelse(YearsAtCompany>25,7,ifelse(YearsAtCompany>20,6,ifelse(YearsAtCompany>15,5,ifelse(YearsAtCompany>10,4,ifelse(YearsAtCompany>5,3,ifelse(YearsAtCompany>2,2,1)))))))))

# Monthly Income Group
empmaster$MonthlyIncomeGroup <- with(empmaster,ifelse(MonthlyIncome>200000,5,ifelse(MonthlyIncome>150000,4,ifelse(MonthlyIncome>100000,3,ifelse(MonthlyIncome>50000,2,ifelse(MonthlyIncome>25000,1,0))))))

View(empmaster)

#-------------------------------------------------------------------------------------------

#------------------------------------- Exploratory Data Analysis ---------------------------

# Function for distribution of categorical variables 
univariate_categorical <- function(dataset,var,var_name){
  dataset %>% ggplot(aes(x = as.factor(var))) +
    geom_bar(aes(y = (..count..)/sum(..count..))) +
    geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +
    scale_y_continuous(labels = percent) +
    labs(title = var_name, y = "Percent", x = var_name)+theme(
      axis.text.y=element_blank(), axis.ticks=element_blank(),
      axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
    ) 
}

# Employee Age Distribution
univariate_categorical(empmaster,empmaster$AgeGroup,"Age Group")
# Employee Attrition Distribution
univariate_categorical(empmaster,empmaster$Attrition,"Attrition")
# Employee Business Travel Distribution
univariate_categorical(empmaster,empmaster$BusinessTravel,"Business Travel")
# Employee Department Distribution
univariate_categorical(empmaster,empmaster$Department,"Department")
# Employee Distance From Home Distribution
univariate_categorical(empmaster,empmaster$DistanceGroup,"Distance From Home Group")
# Employee Education Distribution
univariate_categorical(empmaster,empmaster$Education,"Education")
# Employee Education Field Distribution
univariate_categorical(empmaster,empmaster$EducationField,"EducationField")
# Employee Gender Distribution
univariate_categorical(empmaster,empmaster$Gender,"Gender")
# Employee Job Level Distribution
univariate_categorical(empmaster,empmaster$JobLevel,"JobLevel")
# Employee Job ROle Distribution
univariate_categorical(empmaster,empmaster$JobRole,"JobRole")
# Employee Marital Status Distribution
univariate_categorical(empmaster,empmaster$MaritalStatus,"Marital Status")
# Employee Number of Companies Worked Distribution
univariate_categorical(empmaster,empmaster$NumOfCompWorkedGroup,"Number of Companies Worked")
# Employee Stock Option Level Distribution
univariate_categorical(empmaster,empmaster$StockOptionLevel,"Stock Option Level")
# Employee Total Working Years Distribution
univariate_categorical(empmaster,empmaster$TotalWorkYearsGroup,"Total Working Years")
# Employee Training Times Last Year Distribution
univariate_categorical(empmaster,empmaster$TrainingTimesLastYear,"Training Times Last Year")
# Employee Years At Company Distribution
univariate_categorical(empmaster,empmaster$YearsAtCompanyGroup,"Years At Company")
# Employee Years Since Last Promotion Distribution
univariate_categorical(empmaster,empmaster$YearsSinceLastPromotion,"Years Since Last Promotion")
# Employee Years With Current Manager Distribution
univariate_categorical(empmaster,empmaster$YearsWithManagerGroup,"Years With Current Manager")
# Employee Environment Satisfaction Distribution
univariate_categorical(empmaster,empmaster$EnvironmentSatisfaction,"Environment Satisfaction")
# Employee Job Satisfaction Distribution
univariate_categorical(empmaster,empmaster$JobSatisfaction,"Job Satisfaction")
# Employee Work Life Balance Distribution
univariate_categorical(empmaster,empmaster$WorkLifeBalance,"Work Life Balance")
# Employee Job Involvement Distribution
univariate_categorical(empmaster,empmaster$JobInvolvement,"Job Involvement")
# Employee Performance Rating Distribution
univariate_categorical(empmaster,empmaster$PerformanceRating,"Performance Rating")
# Employee Annual Leave Distribution
univariate_categorical(empmaster,empmaster$AnnualLeave,"Annual Leave")
# Employee Hours spent at office
univariate_categorical(empmaster,empmaster$OfficeHrSpent,"Hours Spent in Office")

# Employee Monthly Income Group
univariate_categorical(empmaster,empmaster$MonthlyIncomeGroup ,"Monthly Income Group")

# Barcharts for categorical features with stacked empmaster information
bar_theme1<- theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
                   legend.position="none")
# Check to see some job roles has high Attrition
# Grid plot to show Age, Attrition, BusinessTravel, Department, DistanceFromHome, Education with Attrition
plot_grid(
  # Influence on Attrition - Age
  ggplot(empmaster,aes(AgeGroup,fill=Attrition))+geom_density()+facet_grid(~Attrition),
  # Percentage based on Business Travel
  ggplot(empmaster, aes(x = BusinessTravel)) + geom_bar(aes(fill = Attrition), position = 'fill') +  scale_y_continuous(labels = percent_format()) + labs(y = "percent"),
  # Influence on Attrition - Department
  ggplot(empmaster,aes(Department,fill = Attrition))+geom_bar(),
  # Influence on Attrition - Distance From Home
  ggplot(empmaster,aes(DistanceGroup,fill=Attrition))+geom_bar(),
  # Influence on Attrition - Education
  ggplot(empmaster,aes(Education,fill=Attrition))+geom_bar())

# Grid plot to show EducationField, EmployeeCount, Gender, JobLevel, JobRole, MaritalStatus with Attrition
plot_grid(
  # Influence on Attrition - EducationField
  ggplot(empmaster,aes(EducationField,fill=Attrition))+geom_bar()+facet_grid(~Attrition),
  # Influence on Attrition - EmployeeCount
  ggplot(empmaster,aes(EmployeeCount,fill=Attrition))+geom_bar()+facet_grid(~Attrition),  
  # Influence on Attrition - Gender
  ggplot(empmaster,aes(Gender,fill=Attrition))+geom_bar(), 
  # Percentage based on Job Level
  ggplot(empmaster, aes(x = JobLevel)) + geom_bar(aes(fill = Attrition), position = 'fill') +  scale_y_continuous(labels = percent_format()) + labs(y = "percent"),
  # Percentage based on Job Role
  ggplot(empmaster, aes(x = JobRole)) + geom_bar(aes(fill = Attrition), position = 'fill') +  scale_y_continuous(labels = percent_format()) + labs(y = "percent"),
  # Percentage based on Marital Status  
  ggplot(empmaster,aes(MaritalStatus,fill=Attrition))+geom_bar())

# Grid plot to show MonthlyIncome,NumCompaniesWorked,Over18,PercentSalaryHike,StandardHours,StockOptionLevel with Attrition
plot_grid(
  # Influence on Attrition - Monthly Income
  ggplot(empmaster,aes(MonthlyIncomeGroup,fill=Attrition))+geom_density(),
  # Influence on Attrition - Number of Companies Worked
  ggplot(empmaster,aes(NumOfCompWorkedGroup,fill=Attrition))+geom_bar(),
  # Influence on Attrition - Percent Salary Hike
  ggplot(empmaster,aes(PercentSalaryHike,Attrition))+geom_point(size=4,alpha = 0.01),
  # Influence on Attrition - Stock Option Level
  ggplot(empmaster,aes(StockOptionLevel,fill = Attrition))+geom_bar())

# Grid plot to show TotalWorkingYears,TrainingTimesLastYear,YearsAtCompany,YearsSinceLastPromotion,
# YearsWithCurrManager,EnvironmentSatisfaction with Attrition
plot_grid(
  # Influence on Attrition - Total Working Years
  ggplot(empmaster,aes(empmaster$TotalWorkYearsGroup,fill = Attrition))+geom_bar(),
  # Influence on Attrition - Training Times Last Year
  ggplot(empmaster,aes(TrainingTimesLastYear,fill = Attrition))+geom_bar(),
  # Influence on Attrition - Years At Company
  ggplot(empmaster,aes(empmaster$YearsAtCompanyGroup,fill = Attrition))+geom_bar(),
  # Influence on Attrition - Years Since Last Promotion
  ggplot(empmaster,aes(YearsSinceLastPromotion,fill = Attrition))+geom_bar(),  
  # Influence on Attrition - Years With Current Manager
  ggplot(empmaster,aes(empmaster$YearsWithManagerGroup,fill = Attrition))+geom_bar(),    
  # Influence on Attrition - Environment
  ggplot(empmaster,aes(EnvironmentSatisfaction,fill=Attrition))+geom_bar())

# Grid plot to show JobSatisfaction,WorkLifeBalance,JobInvolvement,PerformanceRating,meanyrattendance
# annualleave with Attrition
plot_grid(
  # Influence on Attrition - Job Satisfaction
  ggplot(empmaster,aes(JobSatisfaction,fill=Attrition))+geom_bar(),
  # Influence on Attrition - Work Life Balance
  ggplot(empmaster,aes(WorkLifeBalance,fill = Attrition))+geom_bar(),
  # Influence on Attrition - Job Involvement
  ggplot(empmaster,aes(JobInvolvement,fill=Attrition))+geom_bar(),
  # Influence on Attrition - Performance Rating
  ggplot(empmaster,aes(PerformanceRating,fill = Attrition))+geom_bar(),
  # Influence on Attrition - Office Hours Spent
  ggplot(empmaster,aes(OfficeHrSpent,fill = Attrition))+geom_bar(),
  # Influence on Attrition - Total Annual Leave
  ggplot(empmaster,aes(AnnualLeave,fill = Attrition))+geom_bar())

# 16% attrition
prop.table(table(empmaster$Attrition)) # 16% Percentage of Attrition

str(empmaster)
# Boxplots of numeric variables relative to Employee details
plot_grid(ggplot(empmaster, aes(x=Attrition,y=Age, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
ggplot(empmaster, aes(x=Attrition,y=DistanceGroup, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
ggplot(empmaster, aes(x=Attrition,y=Education, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
ggplot(empmaster, aes(x=Attrition,y=JobLevel, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
ggplot(empmaster, aes(x=Attrition,y=MonthlyIncomeGroup, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"))

plot_grid(
  ggplot(empmaster, aes(x=Attrition,y=NumCompaniesWorked, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=PercentSalaryHike, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=StockOptionLevel, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=TotalWorkingYears, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=TrainingTimesLastYear, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"))

plot_grid(
  ggplot(empmaster, aes(x=Attrition,y=YearsAtCompany, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=YearsSinceLastPromotion, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=YearsWithCurrManager, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=EnvironmentSatisfaction, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=JobSatisfaction, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=WorkLifeBalance, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"))

plot_grid(
  ggplot(empmaster, aes(x=Attrition,y=JobInvolvement, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=PerformanceRating, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"),
  ggplot(empmaster, aes(x=Attrition,y=AnnualLeave, fill=Attrition))+ geom_boxplot(width=0.2)+ coord_flip() +theme(legend.position="none"))


# Correlation between numeric variables
ggpairs(empmaster[, c("YearsSinceLastPromotion", "MonthlyIncome", "NumCompaniesWorked","YearsAtCompanyGroup","AnnualLeave","DistanceGroup")])

#---------------------------------- Feature standardisation --------------------------------

# Code: Convert some ints to factors
empmaster$Education <- as.factor(empmaster$Education)
empmaster$EnvironmentSatisfaction <- as.factor(empmaster$EnvironmentSatisfaction)
empmaster$JobInvolvement <- as.factor(empmaster$JobInvolvement)
empmaster$JobSatisfaction <- as.factor(empmaster$JobSatisfaction)
empmaster$PerformanceRating <- as.factor(empmaster$PerformanceRating)
empmaster$WorkLifeBalance <- as.factor(empmaster$WorkLifeBalance)
empmaster$JobLevel <- as.factor(empmaster$JobLevel)
empmaster$StockOptionLevel <- as.factor(empmaster$StockOptionLevel)
empmaster$AgeGroup <- as.factor(empmaster$AgeGroup)
empmaster$DistanceGroup <- as.factor(empmaster$DistanceGroup)
empmaster$Education <- as.factor(empmaster$Education)
empmaster$MonthlyIncomeGroup <- as.factor(empmaster$MonthlyIncomeGroup)
empmaster$OfficeHrSpent <- as.factor(empmaster$OfficeHrSpent)
empmaster$EnvironmentSatisfaction <- as.factor(empmaster$EnvironmentSatisfaction)
empmaster$JobSatisfaction <- as.factor(empmaster$JobSatisfaction)
empmaster$PerformanceRating <- as.factor(empmaster$PerformanceRating)
empmaster$JobInvolvement <- as.factor(empmaster$JobInvolvement)
empmaster$WorkLifeBalance <- as.factor(empmaster$WorkLifeBalance)
empmaster$StockOptionLevel <- as.factor(empmaster$StockOptionLevel)
empmaster$JobLevel <- as.factor(empmaster$JobLevel)

# Normalising continuous features
empmaster$PercentSalaryHike <- scale(empmaster$PercentSalaryHike)
empmaster$YearsSinceLastPromotion <- scale(empmaster$YearsSinceLastPromotion)
empmaster$TrainingTimesLastYear <- scale(empmaster$TrainingTimesLastYear)


# converting target variable empmaster from No/Yes character to factorwith levels 0/1 
empmaster$Attrition <- ifelse(empmaster$Attrition=="Yes",1,0)

# Checking Attrition rate of prospect Employee
Attr <- sum(empmaster$Attrition)/nrow(empmaster)
Attr # 16.12% Attrition rate. 

# creating a dataframe of categorical features
str(empmaster)

empmaster_chr<- empmaster[, -c(1,2,3,6,9,14,15,16,17,18,20,21,22,23,24,30,31)]

# converting categorical attributes to factor
empmaster_fact<- data.frame(sapply(empmaster_chr, function(x) factor(x)))
str(empmaster_fact)

# creating dummy variables for factor attributes
dummies<- data.frame(sapply(empmaster_fact, 
                            function(x) data.frame(model.matrix(~x-1,data =empmaster_fact))[,-1]))

# For variables having only two levels, verified Gender "male" is 1 
# Final dataset
empmaster_final<- cbind(empmaster[,c(2,3,6,9,14,15,16,17,18,20,21,22,23,24,31)],dummies) 

empmaster_final$Age <- NULL
empmaster_final$EmployeeCount <- NULL
empmaster_final$Over18 <- NULL
empmaster_final$StandardHours <- NULL
empmaster_final$MonthlyIncome <- NULL
empmaster_final$DistanceFromHome <- NULL
empmaster_final$YearsWithCurrManager <- NULL
empmaster_final$TotalWorkingYears <- NULL
empmaster_final$NumCompaniesWorked <- NULL
empmaster_final$YearsAtCompany <- NULL

View(empmaster_final) #4410 obs. of 90 variables

str(empmaster_final)

empdata_cor <- empmaster_final

for(i in 1:ncol(empdata_cor)){
  
  empdata_cor[,i]<- as.integer(empdata_cor[,i])
}
corrplot(cor(empdata_cor))

#-------------------------- Multiple Linear Regression -------------------------------------
# check NA's dataset empmaster_final
sum(is.na(empmaster_final)) # 0

#-------------------------------------------------------------------------------------------

########################################################################
# splitting the data between train and test

set.seed(100)

indices = sample.split(empmaster_final$Attrition, SplitRatio = 0.7)

train = empmaster_final[indices,]

test = empmaster_final[!(indices),]

########################################################################
# Logistic Regression: 

#Initial model

model_1 = glm(Attrition ~ ., data = train, family = "binomial")
summary(model_1) 

#-------------------------------------------------------------------------------------------

# Apply the stepwise approach 
# WARNING :: This step takes long to complete, not madatory to execute for evaluation purpose

step <- stepAIC(model_1, direction="both")

#-------------------------------------------------------------------------------------------

# Run the step object
# WARNING ::  Execute only if stepAIC is executed other wise skip

step

#-------------------------------------------------------------------------------------------

model_2 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + EducationField.xMarketing + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                 OfficeHrSpent.xover.time + OfficeHrSpent.xunder.time + AgeGroup.x3 + 
                 AgeGroup.x4 + AgeGroup.x5 + AgeGroup.x7 + DistanceGroup.x5 + 
                 YearsWithManagerGroup.x4 + YearsWithManagerGroup.x5 + TotalWorkYearsGroup.x2 + 
                 TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 + 
                 YearsAtCompanyGroup.x7 + YearsAtCompanyGroup.x8 + YearsAtCompanyGroup.x9, 
                 family = "binomial", data = train)
summary(model_2)
sort(vif(model_2))

#-------------------------------------------------------------------------------------------
# Removing YearsAtCompanyGroup.x8 due to high VIF and less significance
#-------------------------------------------------------------------------------------------

model_3 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + EducationField.xMarketing + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                 OfficeHrSpent.xover.time + OfficeHrSpent.xunder.time + AgeGroup.x3 + 
                 AgeGroup.x4 + AgeGroup.x5 + AgeGroup.x7 + DistanceGroup.x5 + 
                 YearsWithManagerGroup.x4 + YearsWithManagerGroup.x5 + TotalWorkYearsGroup.x2 + 
                 TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 + 
                 YearsAtCompanyGroup.x7 + YearsAtCompanyGroup.x9, 
               family = "binomial", data = train)
summary(model_3)
sort(vif(model_3))


#-------------------------------------------------------------------------------------------
# Removing YearsAtCompanyGroup.x9 due to high VIF and less significance
#-------------------------------------------------------------------------------------------

model_4 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + EducationField.xMarketing + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                 OfficeHrSpent.xover.time + OfficeHrSpent.xunder.time + AgeGroup.x3 + 
                 AgeGroup.x4 + AgeGroup.x5 + AgeGroup.x7 + DistanceGroup.x5 + 
                 YearsWithManagerGroup.x4 + YearsWithManagerGroup.x5 + TotalWorkYearsGroup.x2 + 
                 TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 + 
                 YearsAtCompanyGroup.x7 , family = "binomial", data = train)
summary(model_4)
sort(vif(model_4))

#-------------------------------------------------------------------------------------------
# Removing WorkLifeBalance.x4 due to high VIF and less significance
#-------------------------------------------------------------------------------------------

model_5 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + EducationField.xMarketing + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x2 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                 OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                 AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + YearsWithManagerGroup.x5 +
                 TotalWorkYearsGroup.x2 + TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 + 
                 YearsAtCompanyGroup.x7 , family = "binomial", data = train)
summary(model_5)
sort(vif(model_5))

#-------------------------------------------------------------------------------------------
# Removing WorkLifeBalance.x2 due to high VIF and less significance
#-------------------------------------------------------------------------------------------

model_6 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + EducationField.xMarketing + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                 OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                 AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + YearsWithManagerGroup.x5 +
                 TotalWorkYearsGroup.x2 + TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 + 
                 YearsAtCompanyGroup.x7 , family = "binomial", data = train)
summary(model_6)
sort(vif(model_6))


#-------------------------------------------------------------------------------------------
# Removing EducationField.xMarketing due to high VIF and less significance
#-------------------------------------------------------------------------------------------

model_7 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                 OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                 AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + YearsWithManagerGroup.x5 +
                 TotalWorkYearsGroup.x2 + TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 + 
                 YearsAtCompanyGroup.x7 , family = "binomial", data = train)
summary(model_7)
sort(vif(model_7))

#-------------------------------------------------------------------------------------------
# Removing YearsAtCompanyGroup.x7 due to high p value
#-------------------------------------------------------------------------------------------

model_8 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                 OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                 AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + YearsWithManagerGroup.x5 +
                 TotalWorkYearsGroup.x2 + TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
               family = "binomial", data = train)
summary(model_8)
sort(vif(model_8))

#-------------------------------------------------------------------------------------------
# Removing YearsWithManagerGroup.x5 due to high p value
#-------------------------------------------------------------------------------------------

model_9 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.x3 + Education.x4 + Education.x5 + 
                 EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                 JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                 WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                 OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                 AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                 TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                 TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                 TotalWorkYearsGroup.x9 + NumOfCompWorkedGroup.x2 + NumOfCompWorkedGroup.x3 + 
                 YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
               family = "binomial", data = train)
summary(model_9)
sort(vif(model_9))

#-------------------------------------------------------------------------------------------
# Removing NumOfCompWorkedGroup.x2 due to high p value
#-------------------------------------------------------------------------------------------

model_10 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + Education.x5 + 
                  EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                  JobRole.xResearch.Director + JobRole.xResearch.Scientist + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                  AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_10)
sort(vif(model_10))

#-------------------------------------------------------------------------------------------
# Removing JobRole.xResearch.Scientist due to high p value
#-------------------------------------------------------------------------------------------

model_11 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + Education.x5 + 
                  EducationField.xOther + EducationField.xTechnical.Degree + 
                  JobLevel.x2 + JobLevel.x5 + JobRole.xManufacturing.Director + 
                  JobRole.xResearch.Director + JobRole.xSales.Executive +
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                  AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_11)
sort(vif(model_11))


#-------------------------------------------------------------------------------------------
# Removing Education.x5 due to high p value
#-------------------------------------------------------------------------------------------

model_12 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + EducationField.xOther + 
                  EducationField.xTechnical.Degree + JobLevel.x2 + JobLevel.x5 +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + JobRole.xSales.Executive +
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                  AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_12)
sort(vif(model_12))

#-------------------------------------------------------------------------------------------
# Removing EducationField.xOther due to high p value
#-------------------------------------------------------------------------------------------

model_13 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + EducationField.xTechnical.Degree + JobLevel.x2 + JobLevel.x5 +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + JobRole.xSales.Executive +
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                  AgeGroup.x7 + DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_13)
sort(vif(model_13))


#-------------------------------------------------------------------------------------------
# Removing AgeGroup.x7 due to high p value
#-------------------------------------------------------------------------------------------

model_14 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + EducationField.xTechnical.Degree + JobLevel.x2 + JobLevel.x5 +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + JobRole.xSales.Executive +
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x3 + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_14)
sort(vif(model_14))


#-------------------------------------------------------------------------------------------
# Removing AgeGroup.x3 due to high p value
#-------------------------------------------------------------------------------------------

model_15 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + EducationField.xTechnical.Degree + JobLevel.x2 + JobLevel.x5 +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + JobRole.xSales.Executive +
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_15)
sort(vif(model_15))


#-------------------------------------------------------------------------------------------
# Removing JobLevel.x2 due to high p value
#-------------------------------------------------------------------------------------------

model_16 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + EducationField.xTechnical.Degree + JobLevel.x5 +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + JobRole.xSales.Executive +
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_16)
sort(vif(model_16))

#-------------------------------------------------------------------------------------------
# Removing JobRole.xSales.Executive due to high p value
#-------------------------------------------------------------------------------------------

model_17 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + EducationField.xTechnical.Degree + JobLevel.x5 +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)
summary(model_17)
sort(vif(model_17))


#-------------------------------------------------------------------------------------------
# Removing EducationField.xTechnical.Degree due to high p value
#-------------------------------------------------------------------------------------------

model_18 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + Education.x4 + JobLevel.x5 +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_18)
sort(vif(model_18))

#-------------------------------------------------------------------------------------------
# Removing Education.x4 due to high p value
#-------------------------------------------------------------------------------------------

model_19 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  Education.x3 + JobLevel.x5 + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_19)
sort(vif(model_19))

#-------------------------------------------------------------------------------------------
# Removing Education.x3 due to high p value
#-------------------------------------------------------------------------------------------

model_20 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobLevel.x5 + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_20)
sort(vif(model_20))

#-------------------------------------------------------------------------------------------
# Removing StockOptionLevel.x1 due to high p value
#-------------------------------------------------------------------------------------------

model_21 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobLevel.x5 + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  DistanceGroup.x5 + YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_21)
sort(vif(model_21))

#-------------------------------------------------------------------------------------------
# Removing DistanceGroup.x5  due to high p value
#-------------------------------------------------------------------------------------------

model_22 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobLevel.x5 + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_22)
sort(vif(model_22))

#-------------------------------------------------------------------------------------------
# Removing JobLevel.x5 due to high p value
#-------------------------------------------------------------------------------------------

model_23 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_23)
sort(vif(model_23))

#-------------------------------------------------------------------------------------------
# Removing EnvironmentSatisfaction.x4 due to high p value
#-------------------------------------------------------------------------------------------

model_24 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_24)
sort(vif(model_24))

#-------------------------------------------------------------------------------------------
# Removing JobRole.xResearch.Director due to high p value
#-------------------------------------------------------------------------------------------

model_25 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  YearsWithManagerGroup.x4 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_25)
sort(vif(model_25))

#-------------------------------------------------------------------------------------------
# Removing YearsWithManagerGroup.x4 due to high vif value and less significance
#-------------------------------------------------------------------------------------------

model_26 <- glm(formula = Attrition ~ TrainingTimesLastYear + YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_26)
sort(vif(model_26))

#-------------------------------------------------------------------------------------------
# Removing TrainingTimesLastYear due to high vif value and less significance
#-------------------------------------------------------------------------------------------

model_27 <- glm(formula = Attrition ~ YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_27)
sort(vif(model_27))


#-------------------------------------------------------------------------------------------
# Removing JobSatisfaction.x3 due to high vif value and less significance
#-------------------------------------------------------------------------------------------

model_28 <- glm(formula = Attrition ~ YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x2 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_28)
sort(vif(model_28))

#-------------------------------------------------------------------------------------------
# Removing JobSatisfaction.x2 due to high vif value and less significance
#-------------------------------------------------------------------------------------------

model_29 <- glm(formula = Attrition ~ YearsSinceLastPromotion + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_29)
sort(vif(model_29))

#-------------------------------------------------------------------------------------------
# Removing JobRole.xManufacturing.Director due to high p value
#-------------------------------------------------------------------------------------------

model_30 <- glm(formula = Attrition ~ YearsSinceLastPromotion + 
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_30)
sort(vif(model_30))

#-------------------------------------------------------------------------------------------
# Removing BusinessTravel.xTravel_Rarely to see if further scope for improvement is there
#-------------------------------------------------------------------------------------------

model_31 <- glm(formula = Attrition ~ YearsSinceLastPromotion  + BusinessTravel.xTravel_Frequently + 
                  Department.xResearch...Development + Department.xSales + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                  family = "binomial", data = train)

summary(model_31)
sort(vif(model_31))

#-------------------------------------------------------------------------------------------
# Removing Department.xResearch...Development to see if further scope for improvement is there
#-------------------------------------------------------------------------------------------

model_32 <- glm(formula = Attrition ~ YearsSinceLastPromotion  + BusinessTravel.xTravel_Frequently + 
                 + Department.xSales + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x4 + TotalWorkYearsGroup.x5 + 
                  TotalWorkYearsGroup.x6 + TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_32)
sort(vif(model_32))


#-------------------------------------------------------------------------------------------
# Removing TotalWorkYearsGroup.x4 due to high vif and low significance
#-------------------------------------------------------------------------------------------

model_33 <- glm(formula = Attrition ~ YearsSinceLastPromotion  + BusinessTravel.xTravel_Frequently + 
                  + Department.xSales + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_33)
sort(vif(model_33))

#-------------------------------------------------------------------------------------------
# Removing Department.xSales due to high p value
#-------------------------------------------------------------------------------------------

model_34 <- glm(formula = Attrition ~ YearsSinceLastPromotion  + BusinessTravel.xTravel_Frequently + 
                  + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  TotalWorkYearsGroup.x9 +  NumOfCompWorkedGroup.x3 + 
                  YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_34)
sort(vif(model_34))

#-------------------------------------------------------------------------------------------
# Removing TotalWorkYearsGroup.x9 due to high p value
#-------------------------------------------------------------------------------------------

model_35 <- glm(formula = Attrition ~ YearsSinceLastPromotion  + BusinessTravel.xTravel_Frequently + 
                  + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x3 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  NumOfCompWorkedGroup.x3 +YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_35)
sort(vif(model_35))

#-------------------------------------------------------------------------------------------
# Removing WorkLifeBalance.x3 due to high p value
#-------------------------------------------------------------------------------------------

model_36 <- glm(formula = Attrition ~ YearsSinceLastPromotion  + BusinessTravel.xTravel_Frequently + 
                  + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  NumOfCompWorkedGroup.x3 +YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_36)
sort(vif(model_36))

#-------------------------------------------------------------------------------------------
# Removing YearsSinceLastPromotion due to high p value
#-------------------------------------------------------------------------------------------

model_37 <- glm(formula = Attrition ~  BusinessTravel.xTravel_Frequently + 
                  + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  NumOfCompWorkedGroup.x3 +YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_37)
sort(vif(model_37))


#-------------------------------------------------------------------------------------------
# Removing TotalWorkYearsGroup.x3 due to high p value
#-------------------------------------------------------------------------------------------

model_37 <- glm(formula = Attrition ~  BusinessTravel.xTravel_Frequently + 
                  + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x3 + TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  NumOfCompWorkedGroup.x3 +YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_37)
sort(vif(model_37))

#-------------------------------------------------------------------------------------------
# Removing TotalWorkYearsGroup.x3 due to high p value
#-------------------------------------------------------------------------------------------

model_38 <- glm(formula = Attrition ~  BusinessTravel.xTravel_Frequently + 
                  + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 + TotalWorkYearsGroup.x2 +
                  TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  NumOfCompWorkedGroup.x3 +YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_38)
sort(vif(model_38))


#-------------------------------------------------------------------------------------------
# Removing TotalWorkYearsGroup.x2 due to high p value
#-------------------------------------------------------------------------------------------

model_39 <- glm(formula = Attrition ~  BusinessTravel.xTravel_Frequently + 
                  + MaritalStatus.xSingle + EnvironmentSatisfaction.x1 + 
                  JobSatisfaction.x4 + OfficeHrSpent.xover.time +
                  OfficeHrSpent.xunder.time + AgeGroup.x4 + AgeGroup.x5 +
                  TotalWorkYearsGroup.x5 + TotalWorkYearsGroup.x6 +
                  TotalWorkYearsGroup.x7 + TotalWorkYearsGroup.x8 + 
                  NumOfCompWorkedGroup.x3 +YearsAtCompanyGroup.x2 + YearsAtCompanyGroup.x3 + YearsAtCompanyGroup.x4 ,
                family = "binomial", data = train)

summary(model_39)
sort(vif(model_39))



########################################################################
# With 16 significant variables in the model

final_model<- model_39

#######################################################################

### Model Evaluation

### Test Data ####

#predicted probabilities of Attrition 1 for test data

test_pred = predict(final_model, type = "response", 
                    newdata = test[,])

# Let's see the summary 

summary(test_pred)

test$prob <- test_pred
View(test)
# Let's use the probability cutoff of 50%.

test_pred_churn <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_churn <- factor(ifelse(test$Attrition==1,"Yes","No"))


table(test_actual_churn,test_pred_churn)

#######################################################################
test_pred_churn <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))

#install.packages("caret")
test_conf <- confusionMatrix(test_pred_churn, test_actual_churn, positive = "Yes")
test_conf
#######################################################################

#########################################################################################
# Let's Choose the cutoff value. 
# 

# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_churn <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_churn, test_actual_churn, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Summary of test probability

summary(test_pred)

s = seq(.01,.80,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 


plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(.50,.70,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])< 0.01)]
cutoff

# Choosing 0.1536 for our final model


test_cutoff_churn <- factor(ifelse(test_pred >=0.1536, "Yes", "No"))

conf_final <- confusionMatrix(test_cutoff_churn, test_actual_churn, positive = "Yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

acc

sens

spec

View(test)


##################################################################################################
### KS -statistic - Test Data ######

test_cutoff_churn <- ifelse(test_cutoff_churn=="Yes",1,0)
test_actual_churn <- ifelse(test_actual_churn=="Yes",1,0)


#on testing  data
pred_object_test<- prediction(test_cutoff_churn, test_actual_churn)

performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)

####################################################################
# Lift & Gain Chart 

# plotting the lift chart

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Attrition_decile <- lift(test_actual_churn, test_pred, groups = 10)
Attrition_decile

