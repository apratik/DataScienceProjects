############################# CarPrice Assignment Solution ###################
################################################################
#Business Understanding
#Data Understanding
#Data Preparation & EDA
#Model Building 
#Model Evaluation
################################################################

### Business Understanding:
# A Chinese automobile company Geely Auto aspires to enter the US market by
# setting up their manufacturing unit there and producing cars locally to 
# give competition to their US and European counterparts. 

## AIM:

# The aim is to understand the factors affecting the pricing of cars in the 
# American marketing, since those may be very different from the Chinese market. 
# Essentially, the company wants to know:
# Which variables are significant in predicting the price of a car
# How well those variables describe the price of a car

################################################################

## Import Libraries ############################################
library(dplyr)
library(ggplot2)
library(stringr)
library(DT)
library(tidyr)
library(corrplot)
library(leaflet)
library(lubridate)
library(scales)
library(Hmisc)
library(stargazer)
library(e1071)
library(caret)
library(stringi)
library(pastecs)
library(psych)
library(MASS)
library(epiDisplay)
library(car)
library(boot)

## Load Data ########################################################
car_data <- read.csv("CarPrice_Assignment.csv", header =  T, stringsAsFactors = FALSE)

######### Descriptive statistics Using Stargazer package ############

stargazer(car_data, type = "text", title="Descriptive statistics", digits = 2, out="DescriptiveStat.txt")

# Getting Car Name only
car_data$car_company <-  tolower(gsub( " .*$", "", car_data$CarName))

# Correcting car names
car_data$car_company[car_data$car_company == "maxda" ] <- "mazda"
car_data$car_company[car_data$car_company == "porcshce" ] <- "porsche"
car_data$car_company[car_data$car_company == "toyouta" ] <- "toyota"
car_data$car_company[car_data$car_company == "vokswagen" ] <- "volkswagen"
car_data$car_company[car_data$car_company == "vw" ] <- "volkswagen"

str(car_data)

## Data Cleanup #################################################################

# Check duplicate data if there is any
nrow(car_data) - nrow(unique(car_data)) # 0 - No need to remove any record at this moment

# Remove columns that have unique values - No unique values
col_unique_value = sapply(car_data, function(x) length(unique(x)))

cat("Constant feature count:", length(col_unique_value[col_unique_value==1])) # Constant feature count: 0

names(col_unique_value[col_unique_value==1])

# Removing duplicate columns

car_data = car_data[, !names(car_data) %in% names(col_unique_value[col_unique_value==1])]

##### Handling Missing Data #################

# Drop cases with no car id

car_data <-subset(car_data,!is.na(car_data$car_ID))

# Identifying columns and missing data percentage

data=car_data
ncol=rep(nrow(data) ,each=ncol(data))
missingdata=as.data.frame(cbind(colnames=names(data),ncol,nmsg=as.integer(as.character(as.vector(apply(data, 2, function(x) length(which(is.na(x)))))))))
missingdata$nmsg=as.numeric(levels(missingdata$nmsg))[missingdata$nmsg]

missingdata=cbind(missingdata,percmissing=as.integer(missingdata$nmsg/ncol*100)) # There is no missing data


# Check if duplicate Car ID exists

nrow(car_data)

length(unique(car_data$car_ID)) # No duplicate Car ID

# Missing data check
sum(is.na(car_data))

missing_values <- car_data %>% summarise_all(funs(sum(is.na(.))/n()))
missing_values <- gather(missing_values,key='feature',value = 'missing_percentage')

missing_values %>%
  ggplot(aes(x=reorder(feature,-missing_percentage),y=missing_percentage)) +
  geom_bar(stat = 'identity',fill='red') +
  coord_flip()

# There are some features with redundant values need to be removed
# finding out relevant/good features where the missing % < 15%
good_features <- filter(missing_values,missing_percentage<0.15)

good_features <- (good_features$feature) #the reason for deleting remaining features

car_data <- car_data[,(colnames(car_data) %in% good_features)]

summary(car_data)

# add NA to rows where data is not present

# Check for NA values - price
sum(is.na(car_data$price)) #0 - No "NA" value
str(car_data$price)
summary(car_data$price)

# rounding off the price to 0
car_data$price <- round(car_data$price, 0)



############# Factor conversion of categorical variables ##

#Deriving variable risky based on symboling value - Consider safe when symboling <= 0 otherwise risky
car_data$risky <- ifelse(car_data$symboling <= 0, c('safe'), c('risky'))

# risky as factor
car_data$risky <- as.factor(car_data$risky) 

# car_company as factor
car_data$car_company <- as.factor(car_data$car_company) 

# car_company as factor
car_data$car_company <- as.factor(car_data$car_company) 

# fueltype as factor
car_data$fueltype <- as.factor(car_data$fueltype)

# aspiration as factor
car_data$aspiration <- as.factor(car_data$aspiration)

# doornumber as factor
car_data$doornumber <- as.factor(car_data$doornumber)

# carbody as factor
car_data$carbody <- as.factor(car_data$carbody)

# drivewheel as factor
car_data$drivewheel <- as.factor(car_data$drivewheel)

# enginelocation as factor
car_data$enginelocation <- as.factor(car_data$enginelocation)

# enginetype as factor
car_data$enginetype <- as.factor(car_data$enginetype)

# cylindernumber as factor
car_data$cylindernumber <- as.factor(car_data$cylindernumber)

# fuelsystem as factor
car_data$fuelsystem <- as.factor(car_data$fuelsystem)

str(car_data)

car_data[1:3] <-NULL


######## Start EDA #################################################

# Generic Function for distribution of categorical variables 
univariate_analysis_for_categorical <- function(dataset,var,var_name){
  dataset %>% ggplot(aes(x = as.factor(var))) +
    geom_bar(aes(y = (..count..)/sum(..count..))) +
    geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +
    scale_y_continuous(labels = percent) +
    labs(title = var_name, y = "Percent", x = var_name)+theme(
      axis.text.y=element_blank(), axis.ticks=element_blank(),
      axis.title.y=element_blank(),axis.text.x = element_text(angle = 60, hjust = 1)
    ) 
}

# Analysis of variable car_company
univariate_analysis_for_categorical(car_data,car_data$car_company,"Car Company Analysis")

# Analysis of variable risky
univariate_analysis_for_categorical(car_data,car_data$risky,"Car Risk Analysis")

# Analysis of variable fueltype
univariate_analysis_for_categorical(car_data,car_data$fueltype,"Fuel Type Analysis")

# Analysis of variable aspiration
univariate_analysis_for_categorical(car_data,car_data$aspiration,"Aspiration Analysis")

# Analysis of variable doornumber
univariate_analysis_for_categorical(car_data,car_data$doornumber,"Door Type Analysis")

# Analysis of variable carbody
univariate_analysis_for_categorical(car_data,car_data$carbody,"Car Body Type Analysis")

# Analysis of variable drivewheel
univariate_analysis_for_categorical(car_data,car_data$drivewheel,"Drivewheel Type Analysis")

# Analysis of variable enginelocation
univariate_analysis_for_categorical(car_data,car_data$enginelocation,"Engine Location Analysis")

# Analysis of variable enginetype
univariate_analysis_for_categorical(car_data,car_data$enginetype,"Engine Type Analysis")

# Analysis of variable cylinder
univariate_analysis_for_categorical(car_data,car_data$cylindernumber,"Cylinder Type Analysis")

# Analysis of variable fuelsystem
univariate_analysis_for_categorical(car_data,car_data$fuelsystem,"Fuel System Type Analysis")

# Analysis of wheelbase

describe(car_data$wheelbase)

car_data %>%
  ggplot(aes(x = wheelbase)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Wheelbase')

# Analysis of carlength

describe(car_data$carlength)

car_data %>%
  ggplot(aes(x = carlength)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Car Length')

# Analysis of carwidth

describe(car_data$carwidth)

car_data %>%
  ggplot(aes(x = carwidth)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Car Width')


# Analysis of carheight

describe(car_data$carheight)

car_data %>%
  ggplot(aes(x = carheight)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Car Height')


# Analysis of curbweight

describe(car_data$curbweight)

car_data %>%
  ggplot(aes(x = curbweight)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Curb Weight')

# Analysis of enginesize

describe(car_data$enginesize)

car_data %>%
  ggplot(aes(x = enginesize)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Engine Size')

# Analysis of boreratio

describe(car_data$boreratio)

car_data %>%
  ggplot(aes(x = boreratio)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Bore Ratio')

# Analysis of stroke

describe(car_data$stroke)

car_data %>%
  ggplot(aes(x = stroke)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Stroke')


# Analysis of compressionratio

describe(car_data$compressionratio)

car_data %>%
  ggplot(aes(x = compressionratio)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Compression Ratio')

# Analysis of horsepower

describe(car_data$horsepower)

car_data %>%
  ggplot(aes(x = horsepower)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Horse Power')


# Analysis of peakrpm

describe(car_data$peakrpm)

car_data %>%
  ggplot(aes(x = peakrpm)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Peak RPM')

# Analysis of citympg

describe(car_data$citympg)

car_data %>%
  ggplot(aes(x = citympg)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of City MPG')

# Analysis of highwaympg

describe(car_data$highwaympg)

car_data %>%
  ggplot(aes(x = highwaympg)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Highway MPG')

# Analysis of price

describe(car_data$price)

car_data %>%
  ggplot(aes(x = price)) +
  geom_histogram(col = 'blue', bins = 5, aes(fill = car_company)) +
  ggtitle('Histogram of Price')

# Multivariate Analysis

car_data$risky  <- ifelse(car_data$risky=="safe",1,0)

car_data$fueltypegas <- ifelse(car_data$fueltype=="gas",1,0)

car_data$aspirationstd <- ifelse(car_data$aspiration=="std",1,0)

car_data$doornumbertwo <- ifelse(car_data$doornumber=="two",1,0)

# Create dummy for carbody
dummy_1 <- data.frame(model.matrix( ~carbody, data = car_data))
dummy_1 <- dummy_1[,-1]
car_data <- cbind(car_data, dummy_1)

# Create dummy for drivewheel
dummy_2 <- data.frame(model.matrix( ~drivewheel, data = car_data))
dummy_2 <- dummy_2[,-1]
car_data <- cbind(car_data, dummy_2)

# Convert to numeric
car_data$enginelocfront <- ifelse(car_data$enginelocation=="front",1,0)

# Create dummy for enginetype
dummy_3 <- data.frame(model.matrix( ~enginetype, data = car_data))
dummy_3 <- dummy_3[,-1]
car_data <- cbind(car_data, dummy_3)

# Create dummy for cylindernumber
dummy_4 <- data.frame(model.matrix( ~cylindernumber, data = car_data))
dummy_4 <- dummy_4[,-1]
car_data <- cbind(car_data, dummy_4)

# Create dummy for fuelsystem
dummy_5 <- data.frame(model.matrix( ~fuelsystem, data = car_data))
dummy_5 <- dummy_5[,-1]
car_data <- cbind(car_data, dummy_5)

# Create dummy for car_company
dummy_6 <- data.frame(model.matrix( ~car_company, data = car_data))
dummy_6 <- dummy_6[,-1]
car_data <- cbind(car_data, dummy_6)

summary(car_data)

#Identifying numeric variables
car_data_final <- car_data[sapply(car_data, is.numeric)]

# Create correlation matrix 
correlated_car_data <- cor(car_data_final)

cormat <- round(cor(car_data_final),2)
head(cormat)
melted_cormat <- melt(cormat)
melted_cormat

# Other way to visualize Correlation Matrix
print(correlated_car_data)
# Visualize Correlation Matrix
corrplot(correlated_car_data, order = "FPC", method = "color", type = "lower", tl.cex = 0.7, tl.col = rgb(0, 0, 0))

# Checking Variables that are significantly correlated
correlated_var = findCorrelation(correlated_car_data, cutoff=0.9)

#Identifying Variable Names of significantly Correlated Variables
correlated_columns = colnames(car_data_final)[correlated_var]

#Print highly correlated attributes
correlated_columns


# The following plots show Positive Correlation with price
ggplot(car_data_final, aes(price, wheelbase)) + 
  geom_jitter() + 
  theme_classic() +
  geom_smooth(method = "lm", se = FALSE)

ggplot(car_data_final, aes(price, carlength)) + 
  geom_jitter() + 
  theme_classic() +
  geom_smooth(method = "lm", se = FALSE)

ggplot(car_data_final, aes(price, carwidth)) + 
  geom_jitter() + 
  theme_classic() +
  geom_smooth(method = "lm", se = FALSE)

ggplot(car_data_final, aes(price, curbweight)) + 
  geom_jitter() + 
  theme_classic() +
  geom_smooth(method = "lm", se = FALSE)

ggplot(car_data_final, aes(price, carheight)) + 
  geom_jitter() + 
  theme_classic() +
  geom_smooth(method = "lm", se = FALSE)

ggplot(car_data_final, aes(price, stroke)) + 
  geom_jitter() + 
  theme_classic() +
  geom_smooth(method = "lm", se = FALSE)


######## Linear Regression #################################################

# separate training and testing data
set.seed(100)
trainindices= sample(1:nrow(car_data_final), 0.7*nrow(car_data_final))
train = car_data_final[trainindices,]
test = car_data_final[-trainindices,]

# Build model 1 containing all variables
model_1 <-lm(price~.,data=train)
summary(model_1)

# Now, lets see how to use stepAIC

# In stepAIC function, we pass our first model i.e model_1 and 
# direction is ser as both, because in stepwise,  both the forward selection 
# of variables and backward elimination of variables happen simultaneously 

step <- stepAIC(model_1, direction="both")

# now we need to know our model equation so lets write the Step command here. 

step


# stepAIC makes multiple calls while checking which variables to keep
# The last call that step makes, contains only the variables it considers to be important in the model. 
# some insignifican variables have been removed. 
# Now store the last model equation of stepwise method into an object called model_2
model_2 <- lm(formula = price ~ carlength + carwidth + curbweight + enginesize + 
                boreratio + stroke + peakrpm + citympg + risky + aspirationstd + 
                carbodyhardtop + carbodyhatchback + carbodysedan + carbodywagon + 
                drivewheelrwd + enginelocfront + enginetypedohcv + enginetypel + 
                enginetypeohcf + enginetyperotor + cylindernumberfive + cylindernumberthree + 
                fuelsystem2bbl + fuelsystemmpfi + car_companybmw + car_companybuick + 
                car_companydodge + car_companyhonda + car_companyjaguar + 
                car_companymazda + car_companymercury + car_companymitsubishi + 
                car_companynissan + car_companyplymouth + car_companyrenault + 
                car_companysaab + car_companytoyota + car_companyvolkswagen, 
              data = train)

# Let us look at the summary of the model
summary(model_2)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_2)

# Remove variables as per VIF and p-value
model_3 <- lm(formula = price ~ enginesize + boreratio + stroke + peakrpm + citympg + risky + aspirationstd + 
                           carbodyhardtop + carbodyhatchback + carbodysedan + carbodywagon + 
                           drivewheelrwd + enginelocfront + enginetypedohcv + enginetypel + 
                           enginetypeohcf + enginetyperotor + cylindernumberfive + cylindernumberthree + 
                           fuelsystem2bbl + fuelsystemmpfi + car_companybmw + car_companybuick + 
                           car_companydodge + car_companyhonda + car_companyjaguar + 
                           car_companymazda + car_companymercury + car_companymitsubishi + 
                           car_companynissan + car_companyplymouth + car_companyrenault + 
                           car_companysaab + car_companytoyota + car_companyvolkswagen, 
                         data = train)

# Let us look at the summary of the model
summary(model_3)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_3)

# Remove variables as per VIF and p-value

model_4 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd + 
                carbodyhardtop + drivewheelrwd + enginelocfront + enginetypedohcv +                            enginetypeohcf + enginetyperotor +  fuelsystemmpfi + car_companybmw + car_companybuick + car_companydodge + car_companyhonda + car_companyjaguar + 
                car_companymazda + car_companymitsubishi + 
                car_companynissan + car_companyplymouth + car_companyrenault + car_companytoyota + car_companyvolkswagen, 
              data = train)

# Let us look at the summary of the model
summary(model_4)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_4)


# Remove variables as per VIF and p-value

model_5 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
              + drivewheelrwd + enginelocfront + enginetypedohcv + enginetypeohcf 
              + enginetyperotor + car_companybmw + car_companybuick + car_companydodge 
              + car_companyhonda + car_companyjaguar + car_companymazda + car_companymitsubishi
              + car_companynissan + car_companyplymouth 
              + car_companyrenault + car_companytoyota + car_companyvolkswagen, data = train)

# Let us look at the summary of the model
summary(model_5)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_5)


# Remove variables as per VIF and p-value

model_6 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
              + drivewheelrwd + enginelocfront + enginetypedohcv + enginetypeohcf 
              + enginetyperotor + car_companybmw + car_companybuick + car_companydodge 
              + car_companyhonda + car_companyjaguar + car_companymazda + car_companymitsubishi
              + car_companynissan + car_companyplymouth 
              + car_companytoyota , data = train)

# Let us look at the summary of the model
summary(model_6)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_6)


# Remove variables as per VIF and p-value

model_7 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
              + enginelocfront + enginetypedohcv + enginetypeohcf 
              + enginetyperotor + car_companybmw + car_companybuick + car_companydodge 
              + car_companyjaguar + car_companymitsubishi
              + car_companynissan + car_companyplymouth 
              + car_companytoyota , data = train)

# Let us look at the summary of the model
summary(model_7)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_7)

# Remove variables as per VIF and p-value

model_8 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
              + enginelocfront + enginetypedohcv + enginetypeohcf 
              + enginetyperotor + car_companybmw + car_companybuick + car_companydodge 
              + car_companyjaguar + car_companymitsubishi
              + car_companyplymouth + car_companytoyota , data = train)

# Let us look at the summary of the model
summary(model_8)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_8)


# Remove variables as per VIF and p-value

model_9 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
              + enginelocfront + enginetypedohcv + enginetypeohcf 
              + enginetyperotor + car_companybmw + car_companybuick 
              + car_companyjaguar + car_companymitsubishi, data = train)

# Let us look at the summary of the model
summary(model_9)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_9)

# Remove variables as per VIF and p-value

model_10 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
              + enginelocfront +  enginetypeohcf 
              + enginetyperotor + car_companybmw + car_companybuick 
              + car_companyjaguar, data = train)

# Let us look at the summary of the model
summary(model_10)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_10)

# Additional variable removal to see if we can maintain R Squared value and increase 
# predicted values (R Squared for prediction)
model_11 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
               + enginelocfront +  enginetypeohcf 
               + enginetyperotor + car_companybmw + car_companybuick , data = train)

# Let us look at the summary of the model
summary(model_11)

## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_11)


# Additional variable removal to see if we can maintain R Squared value and increase 
# correlation between test data price and training data price after prediction
model_12 <- lm(formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
               + enginelocfront  
               + enginetyperotor + car_companybmw + car_companybuick , data = train)

# Let us look at the summary of the model
summary(model_12)


## Let us check for multicollinearity and remove 
# the variables if they are statistically insignificant
vif(model_12)

# Since all the variables are significant ("***" i.e. low p-value) model_12 looks good
# We can run prediction now

# predicting the results in test dataset
Predict_1 <- predict(model_12,test[,-1])
test$test_price <- Predict_1

# Now, we need to test the r square between actual and predicted price 
r <- cor(test$price,test$test_price)
rsquared <- cor(test$price,test$test_price)^2
rsquared

# epidisplay to see details of coefficient
epiDisplay::regress.display(model_12)

## Residual normality
qqPlot(model_12)

# Added-Variable Plots
avPlots(model = model_12, id.n = 5)

# Component+Residual (Partial Residual) Plots
crPlots(model = model_12, id.n = 5)

# Influence Index Plot
influenceIndexPlot(model = model_12, id.n = 5)

# Residual Plot
residualPlots(model = model_12, id.n = 5)


# Bootstrap 95% CI for regression coefficients 
# function to obtain regression weights 
bs <- function(formula, data, indices) {
  d <- data[indices,] # allows boot to select sample 
  fit <- lm(formula, data=d)
  return(coef(fit)) 
} 

# bootstrapping with 1000 replications 
results <- boot(data=car_data_final, statistic=bs, 
                R=1000, formula = price ~ enginesize + stroke + peakrpm + aspirationstd 
                + enginelocfront  
                + enginetyperotor + car_companybmw + car_companybuick)

# view results
results
plot(results, index=1) # intercept 
plot(results, index=2) # wt 
plot(results, index=3) # disp 

# get 95% confidence intervals 
boot.ci(results, type="bca", index=1) # intercept 
boot.ci(results, type="bca", index=2) # wt 
boot.ci(results, type="bca", index=3) # disp
