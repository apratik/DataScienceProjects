################ Gramener Case Study  #########################

#seting working directory where input files are copied

setwd("D:/Personal/Abhishek/IIIT B Upgrad/Main-Course/Module2/EDA/LoanCaseStudy")

#importing libraries
library(stringr)
library(ggplot2)
library(moments)
library(stargazer)
library(plyr)
library(dplyr)
library(lubridate)
library(reshape2)

# Loading the data for analysis

loandata<-read.csv("loan.csv", header = TRUE, na.strings=c("","NA"), stringsAsFactors = FALSE)

dim(loandata)

as.data.frame(names(loandata))

######### Descriptive statistics Using Stargazer package #######################

stargazer(loandata, type = "text", title="Descriptive statistics", digits = 2, out="DescriptiveStat.txt")

########## Data Cleaning and preparation  #####################

# Remove duplicate data if there is any
nrow(loandata) - nrow(unique(loandata))

# Remove columns that have unique values
col_unique_value = sapply(loandata, function(x) length(unique(x)))

cat("Constant feature count:", length(col_unique_value[col_unique_value==1]))

names(col_unique_value[col_unique_value==1])

# Removing duplicate columns

loandata = loandata[, !names(loandata) %in% names(col_unique_value[col_unique_value==1])]

##### Handling Missing Data #################

# Drop cases with no member id

loandata <-subset(loandata,!is.na(loandata$member_id))

# Identifying columns and missing data percentage

data=loandata
ncol=rep(nrow(data) ,each=ncol(data))
missingdata=as.data.frame(cbind(colnames=names(data),ncol,nmsg=as.integer(as.character(as.vector(apply(data, 2, function(x) length(which(is.na(x)))))))))
missingdata$nmsg=as.numeric(levels(missingdata$nmsg))[missingdata$nmsg]

missingdata=cbind(missingdata,percmissing=as.integer(missingdata$nmsg/ncol*100))

# Removing columns having less than 50% values populated

loandata <- loandata[, -which(colMeans(is.na(loandata)) > 0.5)]

# Change Class

loandata$int_rate=sub("%","",loandata$int_rate) # Remove %
loandata$int_rate=as.numeric(loandata$int_rate) # Convert to numeric
loandata$revol_util=sub("%","",loandata$revol_util) # Remove %
loandata$revol_util=as.numeric(loandata$revol_util) # Convert to numeric

# Look for Duplicate Member IDs

nrow(loandata)

length(unique(loandata$member_id))

# Data Cleansing

loandata$zip_code=strtrim(loandata$zip_code,3)

# Date Handling 

loandata$issue_d <- as.character(loandata$issue_d)
loandata$issue_d <- paste(loandata$issue_d, "-01", sep = "")
loandata$issue_d <- parse_date_time(loandata$issue_d, "myd")

loandata$earliest_cr_line <- as.character(loandata$earliest_cr_line)
loandata$earliest_cr_line <- paste(loandata$earliest_cr_line, "-01", sep = "")
loandata$earliest_cr_line <- parse_date_time(loandata$earliest_cr_line, "myd")

loandata$last_credit_pull_d <- as.character(loandata$last_credit_pull_d)
loandata$last_credit_pull_d <- paste(loandata$last_credit_pull_d, "-01", sep = "")
loandata$last_credit_pull_d <- parse_date_time(loandata$last_credit_pull_d, "myd")


loandata$last_pymnt_d <- as.character(loandata$last_pymnt_d)
loandata$last_pymnt_d <- paste(loandata$last_pymnt_d, "-01", sep = "")
loandata$last_pymnt_d <- parse_date_time(loandata$last_pymnt_d, "myd")

# Derive variable time_since_first_credit for further analysis
loandata$time_since_first_credit <- loandata$issue_d - loandata$earliest_cr_line
loandata$time_since_first_credit <- as.numeric(loandata$time_since_first_credit)

# Derive variable current_account_ratio for further analysis
loandata$current_account_ratio <- loandata$open_acc / loandata$total_acc


loandata$month_iss=as.character(lubridate::month(loandata$issue_d,label = TRUE, abbr = TRUE)) # Extract Month Ch
loandata$year_iss=as.character(year(loandata$issue_d)) # Extract Year

loandata$month_earl_cr=as.character(lubridate::month(loandata$earliest_cr_line,label = TRUE, abbr = TRUE)) # Extract Month Ch
loandata$year_earl_cr=as.character(year(loandata$earliest_cr_line)) # Extract Year

loandata$month_last_creditp=as.character(lubridate::month(loandata$last_credit_pull_d,label = TRUE, abbr = TRUE)) # Extract Month Ch
loandata$year_last_creditp=as.character(year(loandata$last_credit_pull_d)) # Extract Year

loandata$month_last_pymnt=as.character(lubridate::month(loandata$last_pymnt_d,label = TRUE, abbr = TRUE)) # Extract Month Ch
loandata$year_last_pymnt=as.character(year(loandata$last_pymnt_d)) # Extract Year

# Derive loan_amnt_month for further analysis

loan_amnt_month <- aggregate(loan_amnt ~ month_iss, data = loandata, sum)

loandata$issue_d=as.character(loandata$issue_d)
loandata$earliest_cr_line=as.character(loandata$earliest_cr_line)
loandata$last_credit_pull_d=as.character(loandata$last_credit_pull_d)
loandata$last_pymnt_d=as.character(loandata$last_pymnt_d)

# add NA to rows where data is not present
# Impute NA for all Driver variables.
loandata<-loandata[grep("^[[:digit:]]", loandata$id),]

# Check for NA values - annual_inc
sum(is.na(loandata$annual_inc)) #0
str(loandata$annual_inc)

# Check for NA values - loan_amt
sum(is.na(loandata$loan_amnt)) #0


# Check for NA values - funded_amnt  
sum(is.na(loandata$funded_amnt)) #0

# Check for NA values - funded_amnt
sum(is.na(loandata$int_rate))

# check NULL for grade column and make it a factor
sum(is.null(loandata$grade)) #0

loandata$grade <- as.factor(loandata$grade)

str(loandata$term)

loandata$term_numeric <- as.numeric(gsub("months", "", loandata$term))

# Check NA for dti column
sum(is.na(loandata$dti)) #0

# Check NULL value for emp_length column
sum(is.null(loandata$emp_length)) #0

# it is observed that years, +, < on emp_length column
# cleanup this column to make numeric for analysis purpose
loandata$emp_length<-gsub("\ years","",loandata$emp_length,ignore.case=T)
loandata$emp_length<-gsub("\ year","",loandata$emp_length,ignore.case=T)
loandata$emp_length<-gsub("< 1","0",loandata$emp_length,ignore.case=T)
loandata$emp_length<-gsub("\\+","",loandata$emp_length,ignore.case=T)
  

# Check Null values for purpose column 
sum(is.null(loandata$Purpose)) #1
# convert to factor
loandata$purpose<- as.factor(loandata$purpose)
str(loandata$purpose)
sum(is.null(loandata$purpose)) #1

# check Null values for home_ownership column
sum(is.null(loandata$home_ownership)) # 0
str(loandata$home_ownership)
loandata$home_ownership <- as.factor(loandata$home_ownership)

# Check Null values for loan_status
sum(is.null(loandata$loan_status)) # 0
loandata$loan_status<-as.factor(loandata$loan_status)
str(loandata$loan_status)
summary(loandata$loan_status)

# Deriving default_status variable
loandata$default_status <- ifelse(loandata$loan_status=="Current" | loandata$loan_status=="Fully Paid" ,"Not Defaulted","Defaulted")


# Deriving default_numeric_status variable for creating correlation plots
loandata$default_numeric_status <- ifelse(loandata$loan_status=="Current" | loandata$loan_status=="Fully Paid" ,0,1)


# Create interest rate group variables based on interest rate as Low, Medium, High
loandata$int_rate_grp[loandata$int_rate < 10 ] <- "Low"
loandata$int_rate_grp[loandata$int_rate >= 10 & loandata$int_rate <= 18] <- "Medium"
loandata$int_rate_grp[loandata$int_rate > 18 ] <- "High"
str(loandata$int_rate_grp)
loandata$int_rate_grp<-as.factor(loandata$int_rate_grp)

# Based on emp_length period assign group as Junior, mid-level, senior
loandata$emp_len_grp[loandata$emp_length >=0 & loandata$emp_length <=4 ] <- "Junior"
loandata$emp_len_grp[loandata$emp_length >=5 & loandata$emp_length <=8 ] <- "Mid-level"
loandata$emp_len_grp[loandata$emp_length > 8 ] <- "Senior"
str(loandata$emp_len_grp)
loandata$emp_len_grp <- as.factor(loandata$emp_len_grp)

################# Exploratory Data Analysis  - Univariate  Analysis  ######################

# annual_inc can be a driver variable
summary(loandata$annual_inc)

# skewness to measure of symmetry 
# Based on the skewness value we can say that, the plot is heavily right skewed
# to check if our data has outliers or centered around the mean
skewness(loandata$annual_inc) #30.94802

# kurtosis calculation let us know if data has outliers/centered on mean
#Since kurtosis value is high it is a fat-tailed distribution.
kurtosis(loandata$annual_inc) #2305.448

# With below calculation we can say the spread is approx 92.5% from the mean
# variance calculation for annual_inc
var(loandata$annual_inc) #4069644554
# Standard Deviation calculation for annual_inc
sd(loandata$annual_inc) #63793.77
# co eff of variation
sd(loandata$annual_inc)/mean(loandata$annual_inc) #0.9249639


# box plot to see Outlier
boxplot(loandata$annual_inc, main="Amount Increment", boxwex=0.5)
outliers_inc <- boxplot.stats(loandata$annual_inc)

# to get upper, lower hinge
upper_lower <- outliers_inc$stats[4] - outliers_inc$stats[2] 
steps_upper_lower <- 1.5 * upper_lower

# Replace the outliers with median
loandata$annual_inc[which(loandata$annual_inc < (steps_upper_lower - outliers_inc$stats[2]) | loandata$annual_inc > (steps_upper_lower + outliers_inc$stats[4]))] <- outliers_inc$stats[3]

# Annual Income Plot
loandata %>%
  ggplot(aes(x = annual_inc)) +
  geom_histogram(col = 'blue', bins=100) +
  ggtitle('Annual Income')


# loan_amt can be a driver variable
summary(loandata$loan_amnt)

# skewness to measure of symmetry 
# Based on the value it can be said that plot is lightly right skewed.
# from skewness value we can say that, the plot is lightly right skewed
# to check if our data has outliers or centered around the mean
skewness(loandata$loan_amnt) #1.059277

# kurtosis calculation let us know if data has outliers/centered on mean
# Since kurtosis close to 3 it gives approximate normal distribution and no outliers
kurtosis(loandata$loan_amnt) #3.768421

# With below calculation we can say the spread is 66% from the mean
# variance calculation for annual_inc
var(loandata$loan_amnt) #55601938
# Standard Deviation calculation for annual_inc
sd(loandata$loan_amnt) #7456.671
# co eff of variation
sd(loandata$loan_amnt)/mean(loandata$loan_amnt) #0.6646204


# Loan Amount Plot
loandata %>%
  ggplot(aes(x = loan_amnt)) +
  geom_histogram(col = 'blue', bins=30) +
  ggtitle('Loan Amount')


# funded_amnt can be a driver variable
summary(loandata$funded_amnt)

# skewness to measure of symmetry 
# Based on the above value it can be said that plot is lightly right skewed.
# from skewness value we can say that, the plot is lightly right skewed
# to check if our data has outliers or centered around the mean
skewness(loandata$funded_amnt) #1.081669

# kurtosis calculation let us know if data has outliers/centered on mean
# Since kurtosis just above 3 it gives a medium tailed and has outliers
kurtosis(loandata$funded_amnt) #3.937283

# With below calculation we can say the spread is 65% from the mean
# variance calculation for annual_inc
var(loandata$funded_amnt) #51656400
# Standard Deviation calculation for annual_inc
sd(loandata$funded_amnt) #7187.239
# co eff of variation
sd(loandata$funded_amnt)/mean(loandata$funded_amnt) #0.6565059

# Box Plot to show outliers
boxplot(loandata$funded_amnt, main="Funded amount", boxwex=0.2)
outliers_fun <- boxplot.stats(loandata$funded_amnt)

#upper,lower hinge
upper_lower_fun <- outliers_fun$stats[4] - outliers_fun$stats[2] 

steps_fun <- 1.5 * upper_lower_fun

# only 2.9% of outliers present, we can ignore this because of low impact
length(outliers_fun$out)/length(loandata$funded_amnt) * 100 #2.69%


# Funded Amount Plot
loandata %>%
  ggplot(aes(x = funded_amnt)) +
  geom_histogram(col = 'blue', bins=30) +
  ggtitle('Funded Amount')


# int_rate_grp can be a driver variable
summary(loandata$int_rate)

# skewness to measure of symmetry 
# Based on the value it can be said that plot is lightly right skewed.
# from skewness value we can say that, the plot is lightly right skewed
# to check if our data has outliers or centered around the mean
skewness(loandata$int_rate) #0.2937176

# kurtosis calculation let us know if data has outliers/centered on mean
# Since kurtosis close to 2.5 it gives approximate normal distribution and no outliers
kurtosis(loandata$int_rate) #2.55324

# With below calculation we can say the spread is 31% from the mean
# variance calculation for int_rate
var(loandata$int_rate) #13.87432
# Standard Deviation calculation for int_rate
sd(loandata$int_rate) #3.724825
# co eff of variation
sd(loandata$int_rate)/mean(loandata$int_rate) #0.3098553

#Interest Rate Plot
loandata %>% 
  ggplot(aes(int_rate)) + geom_histogram(col = 'blue', bins = 30) +  ggtitle('Interest Rate')


# Grade has dependency on Interest Rate and hence grade is also a driver variable
summary(loandata$grade)


# dti can be a driver variable
summary(loandata$dti)

# skewness to measure of symmetry 
# Based on the above value it can be said that plot is lightly left skewed.
# from skewness value we can say that, the plot is lightly right skewed
# to check if our data has outliers or centered around the mean
skewness(loandata$dti) #-0.02804227

# from skewness value we can say that, the plot is slightly left skewed
# to check if our data has outliers or centered around the mean, we need to calculate the
# kurtosis
# kurtosis calculation let us know if data has outliers/centered on mean
# Since kurtosis less than 3 it has less outliers
kurtosis(loandata$dti) #2.147941

# With below calculation we can say the spread is 50% from the mean
# variance calculation for annual_inc
var(loandata$dti) #44.60361
# Standard Deviation calculation for annual_inc
sd(loandata$dti) #6.678594
# co eff of variation
sd(loandata$dti)/mean(loandata$dti) #0.5015793

# Boxplot to see any Outlier
boxplot(loandata$dti, main="DTI", boxwex=0.2)
outliers_dti <- boxplot.stats(loandata$dti)

# the below code indicates there are no outliers
upper_lower_dti <- outliers_dti$stats[4] - outliers_dti$stats[2]
steps_dti <- 1.5 * upper_lower_dti
length(outliers_dti$out)/length(loandata$dti) * 100 #0%

#Interesr Rate Plot
loandata %>% 
  ggplot(aes(dti)) + geom_histogram(col = 'blue', bins = 30) +  ggtitle('Debt to Income Ratio')


# emp_len_grp can be a driver variable
summary(loandata$emp_len_grp)

# Current Account Ratio
#Skewness shows slightly right skewed 
skewness(loandata$current_account_ratio)

loandata %>%  ggplot(aes(current_account_ratio)) + geom_histogram(col = 'blue', bins = 30) +  ggtitle('Current Account Ratio')


# Purpose can be a driver variable
summary(loandata$Purpose)

# home_ownership can be a driver variable
summary(loandata$home_ownership)


################# Exploratory Data Analysis  - Multivariate Analysis  ######################

## Correlation of all numeric variable with default_status
mylist <- c()  
for(i in colnames(loandata))
{
  if (class(loandata[,which(colnames(loandata) == i)])  == "integer" | class(loandata[,which(colnames(loandata) == i)])  == "numeric")
  {
    x <- cor(loandata$default_numeric_status, loandata[,which(colnames(loandata) == i)], method = "pearson")
    mylist <- c(mylist, (paste(i,x,sep=" ")))
    
  }
} 

mylist

# annual_inc and loan_amnt correlation
# with 0.34 there is +ve correlation 
cor(loandata$annual_inc, loandata$loan_amnt) #0.3370655 

# with below plot it can be observed its positively correlated
ggplot(loandata,aes(annual_inc,loan_amnt)) + geom_point() + geom_smooth()

# int_rate and loan_amnt correlation
# with 0.30 there is minimal +ve correlation 
cor(loandata$int_rate, loandata$loan_amnt) #0.3094153 

# with below plot it can be observed its positively correlated
ggplot(loandata,aes(int_rate,loan_amnt)) + geom_point() + geom_smooth()


# annual_inc and funded_amnt correlation
# 0.2669652, there is minimal +ve correlation
cor(loandata$annual_inc, loandata$funded_amnt)  
# with below plot it can be observed its positively correlated but relation is not strong
ggplot(loandata,aes(annual_inc,funded_amnt)) + geom_point()+ geom_smooth()

# annual_inc and dti correlation
# -0.0890033 correlation  and negatively related 
cor(loandata$annual_inc, loandata$dti) 

# With below plot it can be observed values scattered, we can not infer relation
ggplot(loandata,aes(annual_inc,dti)) + geom_point() + geom_smooth()

# loan_amnt and funded_amnt correlation 
# 0.9815782 there is strong correlation
cor(loandata$loan_amnt, loandata$funded_amnt) 

# with below plot we can see a linear line with strong correlation
ggplot(loandata,aes(loan_amnt,funded_amnt)) + geom_point()+ geom_smooth()

# loan_amnt and dti correlation
# with 0.06643935 there is no correlation
cor(loandata$loan_amnt, loandata$dti) 

# with the below plot we can see values are scattered, we can not infer relation
ggplot(loandata,aes(loan_amnt,dti)) + geom_point() + geom_smooth()

# funded_amnt and dti correlation
# 0.06628288 there is 0 correlation
cor(loandata$funded_amnt, loandata$dti) 

# with below plot we can see values are scattered and not infer a relation
ggplot(loandata,aes(funded_amnt,dti)) + geom_point() + geom_smooth()


# annual_inc and default_numeric_status correlation
cor(loandata$annual_inc, loandata$default_numeric_status) 



# with below plot we can see values having negative correlation
ggplot(loandata,aes(annual_inc,default_status)) + geom_point() + geom_smooth()


# loan_amnt and default_numeric_status correlation
# 0.06628288 there is 0.04821697 correlation
cor(loandata$loan_amnt, loandata$default_numeric_status) 

# with below plot we can see values having slight positive correlation
ggplot(loandata,aes(loan_amnt,default_numeric_status)) + geom_point() + geom_smooth()

# funded_amnt and default_numeric_status correlation
# 0.04554429 there is slight positive correlation
cor(loandata$funded_amnt, loandata$default_numeric_status) 

# with below plot we can see values are scattered and not infer a relation
ggplot(loandata,aes(funded_amnt,default_numeric_status)) + geom_point() + geom_smooth()


# dti and default_numeric_status correlation
# 0.04170126 there is 0 correlation
cor(loandata$dti, loandata$default_numeric_status) 

# with below plot we can see values don't not infer ant strong relation
ggplot(loandata,aes(dti,default_numeric_status)) + geom_point() + geom_smooth()

# int_rate and default_numeric_status correlation
# 0.1962534 there is positive and strong correlation
cor(loandata$int_rate, loandata$default_numeric_status) 

# with below plot we can see values having very strong relation
ggplot(loandata,aes(int_rate,default_status)) + geom_point() 

# inq_last_6mths and default_numeric_status correlation
#  0.0717166 there is 0 correlation
cor(loandata$inq_last_6mths, loandata$default_numeric_status) 

# with below plot we can see values are scattered and not infer a relation
ggplot(loandata,aes(inq_last_6mths,default_numeric_status)) + geom_point() 

# current_account_ratio and default_numeric_status correlation
# 0.02371852 there is 0 correlation
cor(loandata$current_account_ratio, loandata$default_numeric_status) 

# with below plot we can see values are  not inferring any relation
ggplot(loandata,aes(current_account_ratio,default_numeric_status)) + geom_point() + geom_smooth()

# term_numeric and default_numeric_status correlation
#  0.1460383 there is positive correlation
cor(loandata$term_numeric, loandata$default_numeric_status) 


# data frame datasubset with annual_inc, loan_amt, funded_amt, and dti variables
datasubset <- data.frame(loandata$annual_inc, loandata$loan_amnt, loandata$funded_amnt, loandata$dti,loandata$int_rate,loandata$inq_last_6mths, loandata$current_account_ratio,loandata$default_numeric_status, loandata$term_numeric)

# changing to meaningful column names
colnames(datasubset)<- c("annual_inc","loan_amnt","funded_amnt", "dti","int_rate","inq_last_6mths", "current_account_ratio","default_numeric_status","term_numeric")

# with below correlation it is observed that funded_amt, loan_amt are strong correlated
cor(datasubset)

cormat <- round(cor(datasubset),2)
head(cormat)
melted_cormat <- melt(cormat)
melted_cormat

ggplot(data = melted_cormat, aes(x=Var1, y=Var2, fill=value)) + 
  geom_tile()


# Boxplot to analyse default status, int_rate_grp with current and default customers
ggplot(loandata,aes(x=default_status, y=annual_inc, fill=default_status)) + geom_boxplot()

# Boxplot to analyse interest rate
ggplot(subset(loandata,annual_inc<=100000),aes(x=int_rate_grp, y=annual_inc, fill=int_rate_grp)) + geom_boxplot()

################# various plots for loan data  ######################

# Plot to show default_status wise interest rate variation
ggplot(loandata, aes(x = int_rate)) + geom_histogram(aes(fill = grade), bins=30) + facet_wrap(~default_status, ncol = 1) + labs(x = "Interest Rate", y = "Frequency", title = "Interest Rate Frequencies on Default Status")

# Plot to show default status and loan loan issue year variation
ggplot(loandata, aes(x = year_iss)) + geom_bar(aes(fill = default_status), stat = 'count') + labs(x = "Loan Issue Year", y = "Frequency", title = "Year-wise Default Status Frequencies")

# Plot to show loan amount and interst rate and term variation
ggplot(loandata, aes(x = loan_amnt, y = int_rate)) + geom_point(aes(color = term)) + geom_smooth() + labs(x = "Loan Amount", y = "Interest Rate", title = "Loan Amount and Interest Rate Distribution with Term")

# State wise default frequency
ggplot(loandata, aes(x = addr_state)) + geom_bar( aes(fill = default_status),stat = 'count') + labs(x = "State", y = "Frequency of Default", title = "Statewise Loan default Frequency")

# Employment Length wise default frequency
ggplot(loandata, aes(x = emp_length)) + geom_bar( aes(fill = default_status),stat = 'count')  + labs(x = "Employment Length", y = "Frequency of Default", title = "Employment Length and Loan default Frequency")


# Homeownership wise default frequency
ggplot(loandata, aes(x = home_ownership)) + geom_bar( aes(fill = default_status),stat = 'count') + labs(x = "Home Ownership", y = "Frequency of Default", title = "Home Ownership and Loan default Frequency")


# Verification Status Wise default frequency
ggplot(loandata, aes(x = verification_status)) + geom_bar( aes(fill = default_status),stat = 'count') + labs(x= "Verification Status", y= "Frequency", title = "Verification Status and Default frequency")


# Grade Wise default frequency
ggplot(loandata, aes(x = grade)) + geom_bar( aes(fill = default_status),stat = 'count') + labs(x= "Grade", y= "Frequency", title = "Grade and Default frequency")


# Purpose and default frequency
ggplot(loandata, aes(x = purpose)) + geom_bar( aes(fill = default_status),stat = 'count') + labs(x= "Purpose", y= "Frequency", title = "Purpose and Default frequency")

# loan status distribution
loandata %>% count(default_status) %>%
  ggplot(aes(x = factor(default_status), y = n)) + 
  geom_bar(stat = 'identity', width = 0.6, fill = 'Light Blue') +
  ggtitle('Default Status')

# Default Status by loan amounts
loandata %>%
  ggplot(aes(x = default_status,y = loan_amnt)) +
  geom_boxplot(aes(fill = default_status), col = 'blue') +
  ggtitle('Status by loan amounts')

# Default Status by revol_util
loandata %>%
  ggplot(aes(x = default_status,y = revol_util)) +
  geom_boxplot(aes(fill = default_status), col = 'blue') +
  ggtitle('Status by Rev Utilization')

summary(loandata$int_rate)

#loan status by interest rate
loandata%>%
  ggplot(aes(int_rate)) + geom_histogram(aes(fill = default_status), col = 'blue', bins = 40) +
  ggtitle('loan status by interest rate')



#Distribution of Grade
loandata %>% 
  count(grade) %>%
  ggplot(aes(grade, n)) + geom_bar(stat = 'identity', fill = 'light blue') +
  ggtitle('Distribution of Grade')

#Loan Status by Grade of Loan
loandata %>%
  ggplot(aes(grade)) + geom_bar(aes(fill = default_status)) +
  ggtitle('Loan Status by Grade of Loan')


# Default density on Interest Rate
ggplot(loandata, aes(int_rate, fill = default_status)) + geom_density() + facet_grid(default_status ~ .)

# Grade density and Default status
ggplot(loandata, aes(int_rate, fill = grade)) + geom_density() + facet_grid(grade ~ .)

# Issued month and loan amount 
loan_amnt_month <- aggregate(loan_amnt ~ month_iss, data = loandata, sum)

ggplot(loan_amnt_month, aes(x = month_iss, y = loan_amnt)) + geom_bar(stat = 'identity', col = 'blue')


#Default status by purpose of loan
loandata %>%
  ggplot(aes(purpose)) + geom_bar(aes(fill = default_status)) +
  ggtitle('Default status by purpose of loan')

#Purpose by Grade
loandata %>%
  ggplot(aes(purpose)) + geom_bar(aes(fill = grade)) +
  ggtitle('Purpose by Grade')

loan_amount_grade <- aggregate(loan_amnt ~ sub_grade + default_status, data = loandata, sum) 

#Loan Amount by Sub Grade and status
ggplot(loan_amount_grade,aes(sub_grade, loan_amnt, fill = default_status)) + 
  geom_bar(stat = 'identity', col = 'blue') +
  ggtitle('Loan Amount by Sub Grade and status')


#Interest rate by grade
box_plane = ggplot(loandata, aes(grade,int_rate))
box_plane + geom_boxplot(aes(fill = grade)) +
  labs(title = "Interest rate by grade",
       x = "Grade",
       y = "Interest rate")
#Interest rate by term
box_plane = ggplot(loandata, aes(term,int_rate))
box_plane + geom_boxplot(aes(fill = term)) +
  labs(title = "Interest rate by term",
       x = "Term",
       y = "Interest rate")
#Loan Amount by term
box_plane = ggplot(loandata, aes(term,loan_amnt))
box_plane + geom_boxplot(aes(fill = term)) +
  labs(title = "Loan Amount by term",
       x = "Term",
       y = "Loan Amount")

# Loan Amount , purpose and Default Status plot
ggplot(loandata, aes(purpose, loan_amnt, fill = default_status)) + geom_boxplot() + theme(axis.text.x=element_text(size=8, angle = 90))

loan_by_purpose <- aggregate(loan_amnt ~ purpose + default_status, data = loandata, sum)
ggplot(loan_by_purpose, aes(purpose, loan_amnt, fill = default_status)) + geom_bar(position = "fill", stat = "identity") + theme(axis.text.x=element_text(size=8, angle = 90))

#Annual inc vs. Funded amnt
ggplot(loandata, aes(annual_inc, funded_amnt)) + 
  geom_point(aes(colour = grade)) +
  labs(title = 'annual inc vs. funded amnt') +
  geom_smooth()

#Interest Rate vs. Month
# Jan and Feb is the best month to take loan as the interest rate is lowest
# December is the month where loan rate is highest
ggplot(loandata, aes(x = month_iss, y = int_rate)) + geom_bar(stat = 'identity', col = 'light blue')

# Last 6m inquiry by grade
ggplot(data = loandata, aes(loandata$inq_last_6mths)) + 
  geom_density(aes(colour = grade, fill = grade)) + 
  labs(title = 'Last 6m Inquiry by grade') + xlim(0,30) +
  facet_wrap( ~ grade)

# Other plots on derived variables 

# Add a new column called lc_dti
mydata <- mutate(loandata, monthly_inc = annual_inc/12, lc_dti = installment/monthly_inc)

# lc_dti density by grade
ggplot(data = mydata, aes(lc_dti)) + xlim(0,0.5) +
  geom_density(aes(fill = grade)) +
  facet_grid(grade ~ .)

# Debt-to-Income Ratio (DTI)

d <- ggplot(data = loandata, aes(dti/100)) + xlim(0,1)
d <- d + geom_density(aes(fill = grade))
d + facet_grid(grade ~ .)


mydata <- mutate(mydata, lcd_to_tot_debt = lc_dti / (dti/100))
ggplot(data = mydata, aes(lcd_to_tot_debt)) + xlim(0,1) +
  geom_density(aes(fill = grade)) +
  facet_grid(grade ~ .)



